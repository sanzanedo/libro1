/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BookPage, GlossaryItem, QuizQuestion } from '../types/book';

export const GLOSSARY: Record<string, GlossaryItem> = {
  legitimidad: {
    id: 'legitimidad',
    word: 'legitimidad',
    category: 'sustantivo',
    definition: 'Cualidad de lo que está conforme a las leyes o a un derecho reconocido moral o políticamente.',
    example: 'Isabel defendió con vehemencia la legitimidad de su derecho al trono castellano.',
    translationEn: 'legitimacy',
    pronunciationTip: 'le-xi-ti-mi-DAD',
  },
  proclamacion: {
    id: 'proclamacion',
    word: 'proclamación',
    category: 'sustantivo',
    definition: 'Publicación solemne de un hecho oficial o investidura de un nuevo soberano.',
    example: 'En diciembre de 1474 se celebró la proclamación de Isabel en Segovia.',
    translationEn: 'proclamation',
    pronunciationTip: 'pro-cla-ma-CIÓN',
  },
  clandestina: {
    id: 'clandestina',
    word: 'clandestina',
    category: 'adjetivo',
    definition: 'Hecha en secreto, oculta a las autoridades o sin el consentimiento preceptivo.',
    example: 'La boda clandestina evitó que el rey pudiera interponerse en la alianza.',
    translationEn: 'clandestine / secret',
    pronunciationTip: 'clan-des-TI-na',
  },
  bula_papal: {
    id: 'bula_papal',
    word: 'bula papal',
    category: 'sustantivo',
    definition: 'Documento pontificio sellado con plomo que otorga una dispensa o privilegio eclesiástico.',
    example: 'Al ser primos segundos, los príncipes necesitaban una bula papal para contraer matrimonio.',
    translationEn: 'papal bull / dispensation',
    pronunciationTip: 'BU-la pa-PAL',
  },
  concordia: {
    id: 'concordia',
    word: 'concordia',
    category: 'sustantivo',
    definition: 'Acuerdo, avenencia o pacto pacífico entre personas o bandos contrarios.',
    example: 'La Concordia de Segovia fijó con precisión las funciones de gobierno de cada cónyuge.',
    translationEn: 'accord / concord',
    pronunciationTip: 'con-COR-dia',
  },
  capitulacion: {
    id: 'capitulacion',
    word: 'capitulación',
    category: 'sustantivo',
    definition: 'Convenio militar o político por el cual una plaza sitiada se rinde bajo ciertas condiciones acordadas.',
    example: 'Tras meses de asedio, la capitulación de Granada se rubricó a finales de 1491.',
    translationEn: 'capitulation / surrender agreement',
    pronunciationTip: 'ca-pi-tu-la-CIÓN',
  },
  asedio: {
    id: 'asedio',
    word: 'asedio',
    category: 'sustantivo',
    definition: 'Bloqueo militar continuo alrededor de una fortaleza o ciudad para forzar su rendición.',
    example: 'El campamento de Santa Fe fue erigido para mantener un asedio constante e implacable.',
    translationEn: 'siege',
    pronunciationTip: 'a-SE-dio',
  },
  soberania: {
    id: 'soberania',
    word: 'soberanía',
    category: 'sustantivo',
    definition: 'Poder político supremo que corresponde a un Estado independiente o a su monarca.',
    example: 'Isabel veló siempre por mantener la soberanía exclusiva de la Corona de Castilla.',
    translationEn: 'sovereignty',
    pronunciationTip: 'so-be-ra-NÍ-a',
  },
  santa_hermandad: {
    id: 'santa_hermandad',
    word: 'Santa Hermandad',
    category: 'sustantivo',
    definition: 'Cuerpo policial rural organizado por los Reyes Católicos para garantizar la seguridad en caminos y campos.',
    example: 'Gracias a la Santa Hermandad, el pillaje en las rutas comerciales castellanas disminuyó notablemente.',
    translationEn: 'Holy Brotherhood (rural police force)',
    pronunciationTip: 'SAN-ta er-man-DAD',
  },
  ultramar: {
    id: 'ultramar',
    word: 'ultramar',
    category: 'sustantivo',
    definition: 'Lugar o país que está al otro lado del mar, considerado desde el punto donde se habla.',
    example: 'Las flotas exploraron nuevas rutas hacia territorios de ultramar.',
    translationEn: 'overseas / overseas territories',
    pronunciationTip: 'ul-tra-MAR',
  },
  mecenazgo: {
    id: 'mecenazgo',
    word: 'mecenazgo',
    category: 'sustantivo',
    definition: 'Protección y ayuda económica que se presta a artistas, humanistas o científicos.',
    example: 'La reina ejerció un generoso mecenazgo sobre eruditos como Antonio de Nebrija.',
    translationEn: 'patronage',
    pronunciationTip: 'me-ce-NAZ-go',
  },
  inquisicion: {
    id: 'inquisicion',
    word: 'Inquisición',
    category: 'sustantivo',
    definition: 'Tribunal eclesiástico fundado en 1478 para perseguir la herejía y vigilar a los conversos.',
    example: 'La instauración de la Inquisición supuso una etapa de férreo control ideológico.',
    translationEn: 'Inquisition',
    pronunciationTip: 'in-ki-si-CIÓN',
  },
  herejia: {
    id: 'herejia',
    word: 'herejía',
    category: 'sustantivo',
    definition: 'Creencia o doctrina contraria a los dogmas de una religión establecida.',
    example: 'Los acusados debían comparecer ante el tribunal para responder a cargos de supuesta herejía.',
    translationEn: 'heresy',
    pronunciationTip: 'e-re-XÍ-a',
  },
  ferreo: {
    id: 'férreo',
    word: 'férreo',
    category: 'adjetivo',
    definition: 'De hierro o muy duro, tenaz, inquebrantable.',
    example: 'Gobernó con un pulso férreo que doblegó la rebeldía de los nobles feudales.',
    translationEn: 'iron / unyielding',
    pronunciationTip: 'FÉ-rre-o',
  },
  destierro: {
    id: 'destierro',
    word: 'destierro',
    category: 'sustantivo',
    definition: 'Pena o situación de vivir apartado por orden de la autoridad del lugar donde se reside.',
    example: 'Durante su niñez en Arévalo, Isabel vivió una suerte de discreto destierro palaciego.',
    translationEn: 'exile / banishment',
    pronunciationTip: 'des-TIERRO',
  },
  vasallo: {
    id: 'vasallo',
    word: 'vasallo',
    category: 'sustantivo',
    definition: 'Persona sometida a la autoridad de un rey o señor feudal a quien debe lealtad y servicio.',
    example: 'Isabel estipuló en su testamento que los indígenas debían ser tratados como vasallos libres.',
    translationEn: 'vassal / subject',
    pronunciationTip: 'va-SA-llo',
  },
  albacea: {
    id: 'albacea',
    word: 'albacea',
    category: 'sustantivo',
    definition: 'Persona encargada de hacer cumplir la última voluntad y disposiciones de un testador.',
    example: 'El rey Fernando y el cardenal Cisneros fueron nombrados albaceas de su testamento.',
    translationEn: 'executor of a will',
    pronunciationTip: 'al-ba-CE-a',
  },
  beligerante: {
    id: 'beligerante',
    word: 'beligerante',
    category: 'adjetivo',
    definition: 'Que está en guerra o que muestra una actitud combativa y conflictiva.',
    example: 'Algunos magnates mantuvieron una postura beligerante hasta que fueron reducidos.',
    translationEn: 'belligerent / at war',
    pronunciationTip: 'be-li-xe-RAN-te',
  },
  sublevacion: {
    id: 'sublevacion',
    word: 'sublevación',
    category: 'sustantivo',
    definition: 'Alzamiento colectivo armado contra la autoridad establecida.',
    example: 'La sublevación de la nobleza en Ávila desencadenó años de gran inestabilidad.',
    translationEn: 'uprising / revolt',
    pronunciationTip: 'su-ble-va-CIÓN',
  },
  carabela: {
    id: 'carabela',
    word: 'carabela',
    category: 'sustantivo',
    definition: 'Antigua embarcación ligera, de vela y de casco estrecho, empleada en las expediciones atlánticas.',
    example: 'Las carabelas Pinta y Niña zarparon rumbo a lo desconocido desde Palos de la Frontera.',
    translationEn: 'caravel',
    pronunciationTip: 'ca-ra-BE-la',
  },
  capitulaciones_santa_fe: {
    id: 'capitulaciones_santa_fe',
    word: 'Capitulaciones de Santa Fe',
    category: 'sustantivo',
    definition: 'Documento suscrito en 1492 que concedía a Cristóbal Colón los títulos de almirante y virrey sobre las tierras que descubriese.',
    example: 'Las Capitulaciones de Santa Fe fueron una apuesta audaz de la corona castellana.',
    translationEn: 'Capitulations of Santa Fe',
    pronunciationTip: 'ca-pi-tu-la-CIO-nes de SAN-ta FE',
  },
  no_obstante: {
    id: 'no_obstante',
    word: 'no obstante',
    category: 'locución conjuntiva',
    definition: 'Conector de oposición equivalente a "sin embargo" o "a pesar de ello".',
    example: 'Las arcas reales estaban vacías; no obstante, la reina decidió financiar la empresa ultramarina.',
    translationEn: 'nevertheless / however',
    pronunciationTip: 'no obs-TAN-te',
  },
  a_fin_de_que: {
    id: 'a_fin_de_que',
    word: 'a fin de que',
    category: 'locución conjuntiva',
    definition: 'Conector de finalidad que siempre rige subjuntivo; equivalente a "para que".',
    example: 'Redactó una ordenanza estricta a fin de que los jueces aplicaran las leyes sin favoritismos.',
    translationEn: 'in order that / so that',
    pronunciationTip: 'a fin de ke',
  },
  dado_que: {
    id: 'dado_que',
    word: 'dado que',
    category: 'locución conjuntiva',
    definition: 'Conector de causa formal equivalente a "puesto que" o "ya que".',
    example: 'Dado que la peste asolaba varias ciudades, la corte se trasladaba continuamente de residencia.',
    translationEn: 'given that / since',
    pronunciationTip: 'DA-do ke',
  },
  por_ende: {
    id: 'por_ende',
    word: 'por ende',
    category: 'locución adverbial',
    definition: 'Conector de consecuencia equivalente a "por consiguiente" o "por tanto".',
    example: 'El comercio creció con la paz interior; por ende, los ingresos de la corona se multiplicaron.',
    translationEn: 'therefore / hence',
    pronunciationTip: 'por EN-de',
  },
};

export const BOOK_PAGES: BookPage[] = [
  // Page 1: Portada (Cover)
  {
    id: 'page-1',
    pageNumber: 1,
    chapterIndex: 0,
    chapterTitle: 'Portada',
    type: 'cover',
    image: {
      src: '/src/assets/images/isabel_portrait_1793304504707.jpg',
      caption: 'Retrato de Isabel I de Castilla, reina entre 1474 y 1504.',
      alt: 'Óleo clásico de la reina Isabel I de Castilla con corona y ropaje de terciopelo carmesí',
    },
    paragraphs: [
      {
        id: 'p1-1',
        text: 'ISABEL LA CATÓLICA',
      },
      {
        id: 'p1-2',
        text: 'La reina que transformó los destinos de la Península Ibérica y abrió las puertas a la Edad Moderna.',
      },
      {
        id: 'p1-3',
        text: 'Edición histórica y filológica adaptada a estudiantes de español de nivel B2 (MCER). Incluye glosario léxico interactivo, pronunciación mediante lectura en voz y análisis lingüístico-histórico.',
      },
    ],
  },

  // Page 2: Prólogo & Marco Histórico
  {
    id: 'page-2',
    pageNumber: 2,
    chapterIndex: 0,
    chapterTitle: 'Prólogo y Contexto Histórico',
    subtitle: 'La Castilla del siglo XV: entre la anarquía feudal y el Estado moderno',
    type: 'story',
    paragraphs: [
      {
        id: 'p2-1',
        text: 'A mediados del siglo XV, la Península Ibérica era un mosaico fragmentado de reinos rivales: la Corona de Castilla, la Corona de Aragón, el Reino de Navarra, Portugal y el Emirato Nazarí de Granada. En este tablero de alianzas inestables nació una infanta que nadie imaginaba que llegaría a gobernar.',
        glossaryIds: ['soberania'],
      },
      {
        id: 'p2-2',
        text: 'Isabel I de Castilla (1451-1504) se convertiría en una de las estadistas más influyentes y complejas de la historia universal. Su reinado simbolizó el tránsito definitivo desde la Edad Media hacia el Renacimiento.',
        glossaryIds: ['legitimidad'],
      },
      {
        id: 'p2-3',
        text: 'Este libro le permitirá no solo adentrarse en sus victorias diplomáticas y sus dilemas morales, sino también enriquecer su competencia comunicativa en español mediante estructuras narrativas de nivel B2: tiempos del pasado, oraciones concesivas y léxico formal de la diplomacia y el poder.',
        glossaryIds: ['no_obstante'],
      },
    ],
    quote: {
      text: 'Quien no duda, no aprende bien.',
      author: 'Aforismo de la corte humanista castellana',
    },
    didYouKnow: 'Isabel aprendió latín ya siendo reina adulta, con más de treinta años, para poder leer los despachos diplomáticos sin depender de traductores.',
  },

  // Page 3: Tabla de Contenidos & Guía de Lectura
  {
    id: 'page-3',
    pageNumber: 3,
    chapterIndex: 0,
    chapterTitle: 'Índice de la Obra',
    subtitle: 'Nueve capítulos cronológicos para descubrir a la soberana',
    type: 'table_of_contents',
    paragraphs: [
      { id: 'p3-c1', text: 'Capítulo 1 · Infancia en Madrigal y el destierro en Arévalo (1451-1468)' },
      { id: 'p3-c2', text: 'Capítulo 2 · El Pacto de los Toros de Guisando: La heredera firme (1468)' },
      { id: 'p3-c3', text: 'Capítulo 3 · La boda secreta en Valladolid: Fernando de Aragón (1469)' },
      { id: 'p3-c4', text: 'Capítulo 4 · Proclamación en Segovia y guerra de sucesión (1474-1479)' },
      { id: 'p3-c5', text: 'Capítulo 5 · Orden, justicia y la creación de la Santa Hermandad' },
      { id: 'p3-c6', text: 'Capítulo 6 · La Guerra de Granada: El fin de Al-Ándalus (1482-1492)' },
      { id: 'p3-c7', text: 'Capítulo 7 · Las Capitulaciones de Santa Fe y la odisea de Colón (1492)' },
      { id: 'p3-c8', text: 'Capítulo 8 · Luces y sombras: Inquisición y expulsión de los judíos' },
      { id: 'p3-c9', text: 'Capítulo 9 · El ocaso y el testamento de Medina del Campo (1504)' },
      { id: 'p3-c10', text: 'Actividades B2 · Cuestionario de comprensión lectora y glosario integral' },
    ],
    didYouKnow: 'Haga clic en cualquier palabra resaltada con línea punteada para desplegar su definición, ejemplos y escuchar su pronunciación correcta.',
  },

  // Page 4: Capítulo 1
  {
    id: 'page-4',
    pageNumber: 4,
    chapterIndex: 1,
    chapterTitle: 'Capítulo 1: Infancia en Madrigal y Arévalo',
    subtitle: 'Los primeros años: austeridad, piedad y destierro involuntario',
    type: 'story',
    paragraphs: [
      {
        id: 'p4-1',
        text: 'Isabel vino al mundo el 22 de abril de 1451 en la villa amurallada de Madrigal de las Altas Torres. Su padre, el rey Juan II de Castilla, falleció cuando ella apenas contaba con tres años, dejando la corona en manos de su hermanastro mayor, Enrique IV.',
        glossaryIds: ['destierro'],
      },
      {
        id: 'p4-2',
        text: 'La joven infanta fue trasladada junto a su madre, Isabel de Portugal, y su hermano menor Alfonso al castillo de Arévalo. Allí experimentó una existencia alejada de los lujos cortesanos, marcada por la profunda melancolía materna y una estricta formación religiosa y humanística.',
      },
      {
        id: 'p4-3',
        text: 'No obstante, su apacible vida provincial se truncó bruscamente cuando el rey Enrique la convocó a la corte de Segovia con el propósito de vigilarla de cerca, dado que la nobleza castellana conspiraba para sustituir al monarca.',
        glossaryIds: ['no_obstante', 'dado_que', 'sublevacion'],
      },
    ],
    grammarFocus: {
      title: 'Enfoque Gramatical B2: Contraste de Pasados',
      explanation: 'En las narraciones biográficas se combina el pretérito perfecto simple (acciones puntuales concluidas: "falleció", "se truncó") con el pretérito imperfecto (descripciones y hábitos del entorno: "apenas contaba", "experimentaba").',
      examples: [
        'Cuando tenía tres años, su padre falleció.',
        'La infanta estudiaba con disciplina mientras su madre caía en la tristeza.',
      ],
    },
  },

  // Page 5: Capítulo 1 continuación & Curiosidades
  {
    id: 'page-5',
    pageNumber: 5,
    chapterIndex: 1,
    chapterTitle: 'Capítulo 1: La Corte de los Prodigios',
    subtitle: 'Entre la conspiración nobiliaria y la entereza moral',
    type: 'story',
    paragraphs: [
      {
        id: 'p5-1',
        text: 'En la corte, la infanta Isabel fue testigo de la degradación moral y las intrigas palaciegas. Enrique IV intentó en reiteradas ocasiones casarla con monarcas ancianos o príncipes extranjeros para neutralizar su peso político; sin embargo, ella se negó con firmeza a aceptar enlaces nupciales contra su voluntad.',
        glossaryIds: ['legitimidad', 'ferreo'],
      },
      {
        id: 'p5-2',
        text: 'En 1468, tras la repentina y enigmática muerte de su hermano Alfonso, una facción rebelde de la nobleza le ofreció proclamarse reina en vida de su hermano Enrique. Sorprendiendo a propios y extraños, Isabel rechazó la corona de manera rotunda, argumentando que la corona pertenecía legítimamente a Enrique mientras este viviera.',
        glossaryIds: ['proclamacion', 'legitimidad'],
      },
      {
        id: 'p5-3',
        text: 'Esta demostración de prudencia política desconcertó a sus detractores y cimentó su reputación como una mujer íntegra, capaz de supeditar la ambición personal al respeto por el orden institucional castellano.',
        glossaryIds: ['soberania'],
      },
    ],
    quote: {
      text: 'No tomaré cetro que no me pertenezca por derecho de Dios y ley de mi reino.',
      author: 'Respuesta de Isabel a los nobles de Ávila (1468)',
    },
  },

  // Page 6: Capítulo 2
  {
    id: 'page-6',
    pageNumber: 6,
    chapterIndex: 2,
    chapterTitle: 'Capítulo 2: Los Toros de Guisando',
    subtitle: 'El pacto que reconoció a Isabel como princesa heredera',
    type: 'story',
    paragraphs: [
      {
        id: 'p6-1',
        text: 'Ante la negativa de Isabel a dar un golpe de Estado contra su hermano, Enrique IV no tuvo más remedio que entablar negociaciones de paz. El histórico encuentro tuvo lugar en septiembre de 1468 ante las ancestrales esculturas celtíberas de los Toros de Guisando, en tierras de Ávila.',
        glossaryIds: ['concordia'],
      },
      {
        id: 'p6-2',
        text: 'Allí firmaron un tratado decisivo: Enrique reconoció a Isabel como legítima Princesa de Asturias y heredera al trono de Castilla, desheredando a su propia hija, Juana —llamada despectivamente "la Beltraneja" por quienes dudaban de su paternidad regia—.',
        glossaryIds: ['legitimidad'],
      },
      {
        id: 'p6-3',
        text: 'A cambio, Isabel aceptó una cláusula determinante: no contraería matrimonio sin el previo consentimiento de su hermanastro rey. A pesar de este compromiso, ambos eran plenamente conscientes de que la elección de consorte marcaría el destino de toda la península.',
        glossaryIds: ['a_fin_de_que'],
      },
    ],
    didYouKnow: 'Los "Toros de Guisando" son cuatro esculturas zoomorfas de granito esculpidas por el pueblo vetón hacia el siglo II a.C., hoy monumento nacional.',
  },

  // Page 7: Capítulo 2 continuación
  {
    id: 'page-7',
    pageNumber: 7,
    chapterIndex: 2,
    chapterTitle: 'Capítulo 2: La Elección del Consorte',
    subtitle: 'Diplomacia matrimonial: ¿Portugal, Francia o Aragón?',
    type: 'story',
    paragraphs: [
      {
        id: 'p7-1',
        text: 'Enrique IV propuso de inmediato candidatos afines a sus intereses: primero el veterano rey Alfonso V de Portugal y posteriormente el duque de Guyena, hermano del rey de Francia. No obstante, ninguno de estos pretendientes convencía a la princesa.',
        glossaryIds: ['no_obstante'],
      },
      {
        id: 'p7-2',
        text: 'Isabel vislumbró una visión geopolítica muy superior: la unión de las dos grandes coronas peninsulares mediante el matrimonio con su primo segundo Fernando, heredero de la Corona de Aragón. Esa alianza uniría el poderío militar y demográfico de Castilla con la tradición naval y comercial aragonesa en el mar Mediterráneo.',
        glossaryIds: ['por_ende'],
      },
      {
        id: 'p7-3',
        text: 'Para llevar a término este audaz propósito, Isabel despachó emisarios secretos a Zaragoza con el objetivo de pactar las capitulaciones prematrimoniales a espaldas de su hermanastro.',
        glossaryIds: ['clandestina', 'a_fin_de_que'],
      },
    ],
    grammarFocus: {
      title: 'Enfoque Gramatical B2: El Modo Subjuntivo con Expresiones de Finalidad',
      explanation: 'Las locuciones de finalidad como "con el objetivo de que", "a fin de que" y "para que" siempre exigen el subjuntivo cuando hay cambio de sujeto.',
      examples: [
        'Envió emisarios a fin de que Fernando viajara disfrazado a Castilla.',
        'Pactaron las condiciones para que la corona castellana mantuviera su autonomía.',
      ],
    },
  },

  // Page 8: Capítulo 3: La Boda Secreta (Ilustración)
  {
    id: 'page-8',
    pageNumber: 8,
    chapterIndex: 3,
    chapterTitle: 'Capítulo 3: La Boda Clandestina',
    subtitle: 'Valladolid, 19 de octubre de 1469',
    type: 'illustration',
    image: {
      src: '/src/assets/images/boda_secreta_valladolid_1793304504776.jpg',
      caption: 'Enlace matrimonial de Isabel de Castilla y Fernando de Aragón en el Palacio de los Vivero de Valladolid.',
      alt: 'Pintura histórica del matrimonio entre Isabel de Castilla y Fernando de Aragón bajo arcos góticos y luz de velas',
    },
    paragraphs: [
      {
        id: 'p8-1',
        text: 'Fernando atravesó territorio hostil disfrazado de mozo de mulas para eludir a las patrullas del rey Enrique. El encuentro personal entre los jóvenes novios en Dueñas y su posterior boda en el Palacio de los Vivero sellaron un pacto de acero.',
        glossaryIds: ['clandestina', 'bula_papal'],
      },
    ],
  },

  // Page 9: Capítulo 3 continuación
  {
    id: 'page-9',
    pageNumber: 9,
    chapterIndex: 3,
    chapterTitle: 'Capítulo 3: Amor y Razón de Estado',
    subtitle: 'La bula pontificia y el pacto de gobierno',
    type: 'story',
    paragraphs: [
      {
        id: 'p9-1',
        text: 'Debido a que Isabel y Fernando compartían como bisabuelo común al rey Juan I de Castilla, el derecho canónico exigía una dispensa papal expresa para validar el matrimonio. Dado que el papa Paulo II temía indisponerse con Enrique IV y con Francia, se negó a expedirla.',
        glossaryIds: ['bula_papal', 'dado_que'],
      },
      {
        id: 'p9-2',
        text: 'Sin amedrentarse, el arzobispo Carrillo y el entorno de Fernando recurrieron a una bula papal supuestamente rubricada por el pontífice anterior, una argucia que les permitió contraer nupcias en octubre de 1469. Años más tarde, el nuevo papa Sixto IV regularizaría la situación emitiendo la bula definitiva.',
        glossaryIds: ['bula_papal'],
      },
      {
        id: 'p9-3',
        text: 'Las capitulaciones matrimoniales fueron sumamente estrictas: Fernando se comprometió a residir en Castilla, a combatir en las guerras castellanas y a respetar de forma escrupulosa las leyes, fueros y privilegios del reino.',
        glossaryIds: ['soberania'],
      },
    ],
    quote: {
      text: 'Tanto monta, monta tanto, Isabel como Fernando.',
      author: 'Célebre lema que reflejaba el equilibrio y reciprocidad entre ambos soberanos',
    },
    didYouKnow: 'Isabel tenía 18 años y Fernando 17 cuando se casaron. Pese a que fue un matrimonio de conveniencia política, nació entre ellos un sincero afecto y lealtad mutua.',
  },

  // Page 10: Capítulo 4
  {
    id: 'page-10',
    pageNumber: 10,
    chapterIndex: 4,
    chapterTitle: 'Capítulo 4: Proclamación en Segovia',
    subtitle: 'La muerte de Enrique IV y la guerra de sucesión (1474-1479)',
    type: 'story',
    paragraphs: [
      {
        id: 'p10-1',
        text: 'En la noche del 11 de diciembre de 1474, el rey Enrique IV falleció en Madrid sin haber dejado un testamento indubitado. La noticia llegó velozmente a Segovia, donde residía la princesa Isabel.',
        glossaryIds: ['proclamacion'],
      },
      {
        id: 'p10-2',
        text: 'Sin aguardar a que Fernando regresase de Aragón, Isabel actuó con una celeridad asombrosa. El 13 de diciembre de 1474, vestida con manto de luto y precedida por un hidalgo que portaba la espada desenvainada de la justicia —símbolo exclusivo de la soberanía real—, se hizo proclamar reina de Castilla en la Plaza Mayor de Segovia al grito de: "¡Castilla por la reina doña Isabel!".',
        glossaryIds: ['soberania', 'proclamacion'],
      },
      {
        id: 'p10-3',
        text: 'La reacción no se hizo esperar: una parte destacada de la alta nobleza castellana y el rey Alfonso V de Portugal apoyaron los derechos de la princesa Juana la Beltraneja, desatando una cruenta guerra civil y bélica por el dominio peninsular.',
        glossaryIds: ['beligerante', 'sublevacion'],
      },
    ],
    didYouKnow: 'A Fernando le molestó inicialmente que la espada se portara ante Isabel como si ella fuera reina absoluta sin mencionarlo a él; sin embargo, pronto redactaron la Concordia de Segovia para armonizar sus prerrogativas.',
  },

  // Page 11: Capítulo 4 continuación
  {
    id: 'page-11',
    pageNumber: 11,
    chapterIndex: 4,
    chapterTitle: 'Capítulo 4: La Batalla de Toro',
    subtitle: 'El triunfo de la legitimidad isabelina (1476)',
    type: 'story',
    paragraphs: [
      {
        id: 'p11-1',
        text: 'Durante cinco años aciagos, el reino se desangró en batallas campales y asedios a fortalezas. Isabel desplegó una energía incansable: recorría a caballo decenas de leguas al día para recaudar fondos, pasar revista a las tropas y asegurar la lealtad de concejos municipales.',
        glossaryIds: ['asedio', 'ferreo'],
      },
      {
        id: 'p11-2',
        text: 'El punto de inflexión bélico ocurrió en marzo de 1476 en la Batalla de Toro. Las tropas comandadas por Fernando derrotaron al ejército luso-castellano, consolidando definitivamente la posición de Isabel en el trono.',
        glossaryIds: ['legitimidad'],
      },
      {
        id: 'p11-3',
        text: 'El conflicto concluyó formalmente con la firma del Tratado de Alcáçovas en 1479, en el cual Portugal reconoció a Isabel como reina de Castilla a cambio de la exclusividad en la navegación por la costa atlántica africana, reteniendo Castilla la soberanía de las Islas Canarias.',
        glossaryIds: ['soberania', 'ultramar'],
      },
    ],
    grammarFocus: {
      title: 'Enfoque Gramatical B2: El Uso de Oraciones Concesivas',
      explanation: 'Las oraciones concesivas expresan una dificultad que no impide el cumplimiento de la acción. "A pesar de que" o "pese a que" van seguidas de indicativo si el hecho es certero y conocido, o de subjuntivo si es hipotético o indeterminado.',
      examples: [
        'A pesar de que las tropas enemigas eran más numerosas, los castellanos vencieron en Toro.',
        'Por mucho que los nobles protestaran, la reina no dio su brazo a torcer.',
      ],
    },
  },

  // Page 12: Capítulo 5
  {
    id: 'page-12',
    pageNumber: 12,
    chapterIndex: 5,
    chapterTitle: 'Capítulo 5: Reformas y Pacificación',
    subtitle: 'La Santa Hermandad y el restablecimiento del orden público',
    type: 'story',
    paragraphs: [
      {
        id: 'p12-1',
        text: 'Tras salir victoriosa de la guerra civil, Castilla se hallaba sumida en el pillaje, la extorsión señorial y la inseguridad generalizada. Los caminos estaban infestados de salteadores y los nobles feudales imponían tributos arbitrarios a su antojo.',
      },
      {
        id: 'p12-2',
        text: 'En las Cortes de Madrigal de 1476, Isabel concibió una de las instituciones más eficaces de su reinado: la Santa Hermandad. Dotó a las milicias locales de una estructura unificada, un uniforme característico (jubón con cruz roja) y tribunales sumarios para castigar con presteza los delitos rurales.',
        glossaryIds: ['santa_hermandad', 'ferreo'],
      },
      {
        id: 'p12-3',
        text: 'Asimismo, en las Cortes de Toledo de 1480, la reina obligó a los nobles a devolver gran parte de las rentas y castillos que habían usurpado a la corona durante la anarquía previa. Con esta determinación, el poder feudal quedó supeditado a la autoridad monárquica.',
        glossaryIds: ['soberania'],
      },
    ],
    didYouKnow: 'De los miembros de la Santa Hermandad procede la famosa expresión española "a buenas horas, mangas verdes", pues a menudo sus alguaciles llegaban tarde al lugar de los altercados.',
  },

  // Page 13: Capítulo 5 continuación
  {
    id: 'page-13',
    pageNumber: 13,
    chapterIndex: 5,
    chapterTitle: 'Capítulo 5: Humanismo y Renacimiento',
    subtitle: 'El florecimiento cultural y la gramática de Nebrija',
    type: 'story',
    paragraphs: [
      {
        id: 'p13-1',
        text: 'Lejos de limitarse a la administración de justicia y a la hacienda pública, Isabel mostró un compromiso sin precedentes con la educación y las artes. Ejerció un activo mecenazgo sobre humanistas castellanos e italianos, fundando escuelas palatinas tanto para sus hijos como para los vástagos de la nobleza.',
        glossaryIds: ['mecenazgo'],
      },
      {
        id: 'p13-2',
        text: 'En 1492, el filólogo Antonio de Nebrija le entregó en Salamanca su célebre "Gramática sobre la lengua castellana", la primera gramática impresa de una lengua romance vulgar europea. Al preguntarle la reina para qué serviría dicha obra, el obispo de Ávila contestó proféticamente: "La lengua siempre fue compañera del imperio".',
        glossaryIds: ['mecenazgo'],
      },
      {
        id: 'p13-3',
        text: 'La reina también fomentó la naciente imprenta en ciudades como Sevilla, Salamanca y Toledo, eximiendo de impuestos a los impresores a fin de que el conocimiento circulara con mayor ligereza por sus reinos.',
        glossaryIds: ['a_fin_de_que'],
      },
    ],
    quote: {
      text: 'Siempre fue la lengua compañera del imperio: y de tal manera lo siguió, que junta mente començaron, crecieron y florecieron.',
      author: 'Prólogo de Antonio de Nebrija a su Gramática Castellana (1492)',
    },
  },

  // Page 14: Capítulo 6: La Toma de Granada (Ilustración)
  {
    id: 'page-14',
    pageNumber: 14,
    chapterIndex: 6,
    chapterTitle: 'Capítulo 6: La Guerra de Granada',
    subtitle: 'El asedio final y la rendición de Boabdil (1482-1492)',
    type: 'illustration',
    image: {
      src: '/src/assets/images/toma_de_granada_1793304506371.jpg',
      caption: '2 de enero de 1492: Entrega de las llaves de la Alhambra por el emir Boabdil a los Reyes Católicos.',
      alt: 'Pintura histórica que representa la rendición de Granada con la fortaleza roja de la Alhambra al fondo',
    },
    paragraphs: [
      {
        id: 'p14-1',
        text: 'Durante diez extenuantes años de campañas militares, Isabel organizó hospitales de campaña móviles con medicinas y cirujanos —una novedad pionera en Europa—. El 2 de enero de 1492, la bandera de Castilla ondeó en la Torre de la Vela de la Alhambra, culminando ocho siglos de Reconquista.',
        glossaryIds: ['asedio', 'capitulacion'],
      },
    ],
  },

  // Page 15: Capítulo 6 continuación
  {
    id: 'page-15',
    pageNumber: 15,
    chapterIndex: 6,
    chapterTitle: 'Capítulo 6: La Capitulación de Granada',
    subtitle: 'El campamento de Santa Fe y la generosidad inicial',
    type: 'story',
    paragraphs: [
      {
        id: 'p15-1',
        text: 'Cuando un incendio accidental destruyó el campamento real frente a Granada en 1491, Isabel ordenó erigir en un tiempo récord una auténtica ciudad de piedra y ladrillo en forma de cruz, a la que bautizó con el nombre de Santa Fe, demostrando a los sitiados que jamás levantarían el asedio.',
        glossaryIds: ['asedio'],
      },
      {
        id: 'p15-2',
        text: 'Las capitulaciones pactadas con el emir Boabdil fueron en un inicio sumamente tolerantes: garantizaban a los musulmanes el respeto a su fe, su lengua árabe, sus costumbres tradicionales y sus bienes patrimoniales.',
        glossaryIds: ['capitulacion'],
      },
      {
        id: 'p15-3',
        text: 'La caída de Granada resonó en toda la cristiandad europea como una compensación providencial frente a la pérdida de Constantinopla acaecida cuatro décadas atrás. En reconocimiento a esta proeza, el papa Alejandro VI concedió en 1496 a Isabel y Fernando el título honorífico de "Reyes Católicos".',
        glossaryIds: ['soberania'],
      },
    ],
    didYouKnow: 'Cuenta la leyenda romántica que la madre de Boabdil, Aixa, le increpó al abandonar Granada: "Llora como mujer lo que no supiste defender como hombre".',
  },

  // Page 16: Capítulo 7: Colón y Santa Fe (Ilustración)
  {
    id: 'page-16',
    pageNumber: 16,
    chapterIndex: 7,
    chapterTitle: 'Capítulo 7: La Odisea Colombina',
    subtitle: 'Las Capitulaciones de Santa Fe y el Nuevo Mundo (1492)',
    type: 'illustration',
    image: {
      src: '/src/assets/images/isabel_colon_santa_fe_1793304505775.jpg',
      caption: 'Audiencia de Cristóbal Colón ante la reina Isabel en el campamento real de Santa Fe.',
      alt: 'Pintura renacentista de Isabel de Castilla y Cristóbal Colón examinando mapas marítimos',
    },
    paragraphs: [
      {
        id: 'p16-1',
        text: 'A pesar de que los sabios de la Universidad de Salamanca desaconsejaban la expedición por considerar erróneos los cálculos sobre el radio terrestre, la reina confió en la intuición de Colón y autorizó el histórico viaje hacia las Indias por occidente.',
        glossaryIds: ['capitulaciones_santa_fe', 'carabela', 'ultramar'],
      },
    ],
  },

  // Page 17: Capítulo 7 continuación
  {
    id: 'page-17',
    pageNumber: 17,
    chapterIndex: 7,
    chapterTitle: 'Capítulo 7: La Apuesta por el Océano',
    subtitle: 'El mito de las joyas y el nacimiento de una era global',
    type: 'story',
    paragraphs: [
      {
        id: 'p17-1',
        text: 'Existe la extendida leyenda popular de que Isabel empeñó sus joyas personales para financiar la travesía; sin embargo, las investigaciones históricas demuestran que la mayor parte del dinero fue adelantado por el banquero y cortesano Luis de Santángel, además de la aportación de la villa de Palos.',
        glossaryIds: ['no_obstante'],
      },
      {
        id: 'p17-2',
        text: 'El 17 de abril de 1492 se firmaron las Capitulaciones de Santa Fe, en virtud de las cuales Colón recibía el título hereditario de Almirante del Mar Océano, Virrey y Gobernador de las tierras descubiertas, más un diezmo de las riquezas obtenidas.',
        glossaryIds: ['capitulaciones_santa_fe', 'soberania'],
      },
      {
        id: 'p17-3',
        text: 'El 12 de octubre de 1492, tras dos largos meses de navegación en las carabelas, Rodrigo de Triana avistó la isla de Guanahaní. El horizonte geográfico de la humanidad quedaba transformado para siempre, inaugurando una era de intercambios culturales, botánicos y humanos.',
        glossaryIds: ['carabela', 'ultramar'],
      },
    ],
    grammarFocus: {
      title: 'Enfoque Gramatical B2: El Discurso Referido (Estilo Indirecto)',
      explanation: 'Para reproducir lo que dijeron personajes históricos en pasado, se aplican correlaciones temporales: presente -> pretérito imperfecto; pretérito indefinido -> pluscuamperfecto.',
      examples: [
        'Colón afirmó: "Llegaré a Asia navegando hacia el oeste". -> Colón afirmó que llegaría a Asia navegando hacia el oeste.',
        'La reina declaró que apoyaría su empresa.',
      ],
    },
  },

  // Page 18: Capítulo 8
  {
    id: 'page-18',
    pageNumber: 18,
    chapterIndex: 8,
    chapterTitle: 'Capítulo 8: Luces y Sombras',
    subtitle: 'La Inquisición y el decreto de expulsión de 1492',
    type: 'story',
    paragraphs: [
      {
        id: 'p18-1',
        text: 'El reinado de Isabel no puede comprenderse en su totalidad sin examinar sus páginas más controvertidas y dolorosas. En una época en la que la unidad política se concebía inseparable de la unidad confesional, la reina priorizó la homogeneidad religiosa de sus súbditos.',
        glossaryIds: ['soberania'],
      },
      {
        id: 'p18-2',
        text: 'En 1478, a petición de los reyes, el papa instituyó el Tribunal del Santo Oficio de la Inquisición, con el objetivo de vigilar que los conversos de origen judío y musulmán no practicaran en secreto sus antiguos cultos. Tomás de Torquemada se erigió en su primer y severo Inquisidor General.',
        glossaryIds: ['inquisicion', 'herejia', 'ferreo'],
      },
      {
        id: 'p18-3',
        text: 'El 31 de marzo de 1492, apenas tres meses después de la toma de Granada, se promulgó el Edicto de Granada, que obligaba a la comunidad judía a elegir entre el bautismo forzoso o el destierro definitivo en un plazo improrrogable de cuatro meses.',
        glossaryIds: ['destierro'],
      },
    ],
    didYouKnow: 'Decenas de miles de judíos sefardíes abandonaron la península llevando consigo la lengua castellana del siglo XV, que conservaron y transmitieron generación tras generación como idioma judeoespañol o ladino.',
  },

  // Page 19: Capítulo 8 continuación
  {
    id: 'page-19',
    pageNumber: 19,
    chapterIndex: 8,
    chapterTitle: 'Capítulo 8: Consecuencias Humanas',
    subtitle: 'El impacto demográfico, económico y cultural del exilio',
    type: 'story',
    paragraphs: [
      {
        id: 'p19-1',
        text: 'A pesar de que eminentes personalidades hebreas como el diplomático Isaac Abravanel ofrecieron cuantiosas sumas de dinero a la corona para revocar la orden, la resolución de Isabel y Fernando resultó inflexible.',
        glossaryIds: ['no_obstante', 'ferreo'],
      },
      {
        id: 'p19-2',
        text: 'La expulsión supuso un golpe desolador para el tejido mercantil, médico y científico de las urbes castellanas y aragonesas. Por ende, muchas ciudades tardaron decenios en recobrar su pulso productivo e intelectual.',
        glossaryIds: ['por_ende'],
      },
      {
        id: 'p19-3',
        text: 'Posteriormente, en 1502, tras la rebelión de las Alpujarras, se decretó igualmente la conversión o expulsión de los mudéjares granadinos, dando al traste con el espíritu de convivencia que había caracterizado a la península durante siglos.',
        glossaryIds: ['sublevacion'],
      },
    ],
    quote: {
      text: 'La memoria de Sefarad pervive como el eco de un adiós forzado en las murallas de nuestras viejas juderías.',
      author: 'Reflexión histórica contemporánea',
    },
  },

  // Page 20: Capítulo 9
  {
    id: 'page-20',
    pageNumber: 20,
    chapterIndex: 9,
    chapterTitle: 'Capítulo 9: El Ocaso de la Reina',
    subtitle: 'Medina del Campo y el testamento de 1504',
    type: 'story',
    paragraphs: [
      {
        id: 'p20-1',
        text: 'Los últimos años de la reina estuvieron ensombrecidos por profundas tragedias personales: el fallecimiento sucesivo de su hijo varón y heredero Juan (1497), de su hija mayor Isabel (1498) y de su pequeño nieto Miguel de la Paz (1500). Además, su hija Juana comenzó a mostrar severos síntomas de inestabilidad emocional.',
      },
      {
        id: 'p20-2',
        text: 'Postrada en el Palacio Real Testamentario de Medina del Campo a causa de una hidropesía terminal, Isabel dictó con serenidad admirable su célebre testamento y codicilo en octubre de 1504.',
        glossaryIds: ['albacea'],
      },
      {
        id: 'p20-3',
        text: 'En dicho documento legislativo introdujo un párrafo revolucionario para el derecho indiano de la época: mandó expresamente a sus sucesores que no consintiesen que los indígenas del Nuevo Mundo sufrieran agravio alguno en sus personas y bienes, ordenando que fuesen tratados como vasallos libres y evangelizados con amor.',
        glossaryIds: ['vasallo', 'ultramar', 'soberania'],
      },
    ],
    didYouKnow: 'El testamento de Isabel la Católica es custodiado hoy en el Archivo General de Simancas (Valladolid) y constituye uno de los antecedentes morales de las Leyes de Indias y los derechos humanos.',
  },

  // Page 21: Capítulo 9 continuación
  {
    id: 'page-21',
    pageNumber: 21,
    chapterIndex: 9,
    chapterTitle: 'Capítulo 9: El Legado Imperecedero',
    subtitle: 'El descanso en la Capilla Real de Granada',
    type: 'story',
    paragraphs: [
      {
        id: 'p21-1',
        text: 'El 26 de noviembre de 1504, a los 53 años de edad, expiró Isabel en Medina del Campo. De acuerdo con sus deseos póstumos, su féretro fue conducido en una penosa marcha invernal bajo lluvias torrenciales y puentes caídos hasta Granada.',
      },
      {
        id: 'p21-2',
        text: 'Allí reposa para la eternidad junto a su esposo Fernando en una sobria cripta de plomo situada bajo los suntuosos sepulcros renacentistas de mármol de Carrara en la Capilla Real.',
      },
      {
        id: 'p21-3',
        text: 'Gobernante controvertida, estratega infatigable y mujer adelantada a las limitaciones impuestas a su sexo en el siglo XV, la figura de Isabel la Católica sigue suscitando debates apasionados entre los historiadores de todo el orbe.',
        glossaryIds: ['soberania'],
      },
    ],
    quote: {
      text: 'Y no consientan ni den lugar a que los indios vecinos y moradores de las dichas Indias reciban agravio alguno en sus personas y bienes; mas manden que sean bien y justamente tratados.',
      author: 'Codicilo del Testamento de Isabel la Católica (1504)',
    },
  },

  // Page 22: Taller de Comprensión Lectora B2
  {
    id: 'page-22',
    pageNumber: 22,
    chapterIndex: 10,
    chapterTitle: 'Taller de Comprensión B2',
    subtitle: 'Evaluación formativa de destrezas lectoras y léxicas',
    type: 'activities',
    paragraphs: [
      {
        id: 'p22-1',
        text: 'Ponga a prueba su comprensión lectora sobre la vida de Isabel la Católica con las siguientes preguntas diseñadas según los criterios de certificación de nivel B2 (DELE / SIELE).',
      },
    ],
  },

  // Page 23: Taller de Comprensión B2 (Interactivo)
  {
    id: 'page-23',
    pageNumber: 23,
    chapterIndex: 10,
    chapterTitle: 'Actividades de Léxico y Debate',
    subtitle: 'Expresión oral, conectores y vocabulario contextual',
    type: 'activities',
    paragraphs: [
      {
        id: 'p23-1',
        text: 'Temas para el debate histórico en clase de B2: ¿En qué medida la unificación religiosa respondió a una convicción íntima o a una pragmática razón de Estado?',
      },
      {
        id: 'p23-2',
        text: 'Consulte el glosario interactivo para repasar términos fundamentales como: bula papal, capitulación, concordia, asedio y legitimidad dinástica.',
        glossaryIds: ['bula_papal', 'capitulacion', 'concordia', 'asedio', 'legitimidad'],
      },
    ],
  },

  // Page 24: Glosario Histórico y Lingüístico
  {
    id: 'page-24',
    pageNumber: 24,
    chapterIndex: 10,
    chapterTitle: 'Glosario B2 Seleccionado',
    subtitle: 'Términos de diplomacia, política, sociedad y religión',
    type: 'glossary_view',
    paragraphs: [
      {
        id: 'p24-1',
        text: 'Este repertorio reúne las palabras y locuciones más relevantes aparecidas a lo largo del texto con su definición formal en español adaptada al nivel B2 y su equivalencia en inglés.',
      },
    ],
  },
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    chapterNumber: 1,
    question: '¿Por qué rechazó Isabel proclamarse reina de Castilla en 1468 tras fallecer su hermano Alfonso?',
    options: [
      'Porque temía que el rey de Portugal invadiera Castilla.',
      'Porque consideraba que el rey legítimo continuaba siendo su hermanastro Enrique IV.',
      'Porque no contaba con el apoyo de la Iglesia católica.',
      'Porque prefería casarse primero con el duque de Guyena.',
    ],
    correctIndex: 1,
    explanation: 'Correcto. Isabel mostró un enorme sentido institucional al argumentar que mientras Enrique IV viviera, la corona le pertenecía legítimamente a él.',
  },
  {
    id: 'q2',
    chapterNumber: 2,
    question: '¿Qué estipuló el acuerdo firmado en los Toros de Guisando en 1468?',
    options: [
      'El matrimonio obligatorio de Isabel con el rey de Francia.',
      'La entrega inmediata del reino nazarí de Granada a Castilla.',
      'El reconocimiento de Isabel como heredera de Castilla en detrimento de Juana la Beltraneja.',
      'La creación inmediata del Tribunal de la Santa Inquisición.',
    ],
    correctIndex: 2,
    explanation: 'Correcto. En los Toros de Guisando, Enrique IV reconoció a Isabel como Princesa de Asturias y heredera legal al trono.',
  },
  {
    id: 'q3',
    chapterNumber: 3,
    question: '¿Qué dificultad legal y canónica debieron sortear Isabel y Fernando para casarse en 1469?',
    options: [
      'Fernando no pertenecía a ninguna casa real europea.',
      'Al ser primos segundos, requerían una dispensa papal que el pontífice se negaba a otorgar.',
      'Las leyes de Castilla prohibían taxativamente el matrimonio con extranjeros.',
      'La boda requería el permiso expreso del rey de Francia.',
    ],
    correctIndex: 1,
    explanation: 'Correcto. Su parentesco requería una bula pontificia de dispensa, por lo que recurrieron inicialmente a una bula de conveniencia hasta que años después el papa Sixto IV lo ratificó.',
  },
  {
    id: 'q4',
    chapterNumber: 5,
    question: '¿Cuál era el objetivo primordial de la Santa Hermandad creada por los Reyes Católicos?',
    options: [
      'Organizar las expediciones marítimas hacia las Indias occidentales.',
      'Pacificar los campos y caminos persiguiendo el bandolerismo y los abusos señoriales.',
      'Traducir al latín todas las obras literarias castellanas.',
      'Reclutar soldados para invadir el reino de Navarra.',
    ],
    correctIndex: 1,
    explanation: 'Correcto. La Santa Hermandad funcionó como un cuerpo policial y judicial de ámbito rural que devolvió la seguridad y la ley a los caminos castellanos.',
  },
  {
    id: 'q5',
    chapterNumber: 7,
    question: '¿Qué documento oficial de abril de 1492 fijó las condiciones y recompensas del viaje de Colón?',
    options: [
      'El Tratado de Tordesillas.',
      'La Concordia de Segovia.',
      'Las Capitulaciones de Santa Fe.',
      'El Edicto de Granada.',
    ],
    correctIndex: 2,
    explanation: 'Correcto. Las Capitulaciones de Santa Fe concedían a Colón los títulos de almirante, virrey y gobernador sobre las tierras que descubriese.',
  },
  {
    id: 'q6',
    chapterNumber: 9,
    question: '¿Qué disposición trascendental respecto a los indígenas incluyó Isabel en su testamento de 1504?',
    options: [
      'Que fueran reducidos a la esclavitud para trabajar las minas de plata.',
      'Que fueran tratados como vasallos libres y respetados en sus personas y bienes.',
      'Que fueran trasladados obligatoriamente a la península ibérica.',
      'Que las tierras americanas fueran devueltas a la Corona de Portugal.',
    ],
    correctIndex: 1,
    explanation: 'Correcto. Isabel exigió que los indígenas fuesen considerados vasallos de la corona, prohibiendo su esclavitud y ordenando que no sufrieran agravio alguno.',
  },
];
