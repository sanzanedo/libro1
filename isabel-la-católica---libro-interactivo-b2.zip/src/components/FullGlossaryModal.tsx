/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { GLOSSARY } from '../data/bookContent';
import { GlossaryItem, WordCategory } from '../types/book';
import { Search, Volume2, X, Check, BookMarked, Filter } from 'lucide-react';
import { speechReader } from '../utils/audio';

interface FullGlossaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTerm?: (term: GlossaryItem) => void;
}

export const FullGlossaryModal: React.FC<FullGlossaryModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [learnedTerms, setLearnedTerms] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('isabel_b2_learned_terms');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const toggleLearned = (id: string) => {
    setLearnedTerms(prev => {
      const updated = { ...prev, [id]: !prev[id] };
      try {
        localStorage.setItem('isabel_b2_learned_terms', JSON.stringify(updated));
      } catch {
        // ignore storage errors
      }
      return updated;
    });
  };

  const termsList = useMemo(() => Object.values(GLOSSARY), []);

  const categories = useMemo(() => {
    const cats = new Set<string>();
    termsList.forEach(t => cats.add(t.category));
    return ['todos', ...Array.from(cats)];
  }, [termsList]);

  const filteredTerms = useMemo(() => {
    return termsList.filter(item => {
      const matchesSearch = 
        item.word.toLowerCase().includes(search.toLowerCase()) ||
        item.definition.toLowerCase().includes(search.toLowerCase()) ||
        item.translationEn.toLowerCase().includes(search.toLowerCase());
      
      const matchesCat = selectedCategory === 'todos' || item.category === selectedCategory;
      return matchesSearch && matchesCat;
    });
  }, [termsList, search, selectedCategory]);

  const playTerm = (item: GlossaryItem, e: React.MouseEvent) => {
    e.stopPropagation();
    speechReader.speakText({
      text: `${item.word}. ${item.definition}`,
      rate: 0.9,
    });
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-6 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-3xl h-[85vh] flex flex-col bg-stone-900 border border-amber-600/30 rounded-2xl shadow-2xl overflow-hidden text-stone-100"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-stone-800 flex items-center justify-between shrink-0 bg-stone-900/90">
          <div>
            <div className="flex items-center gap-2">
              <BookMarked className="w-5 h-5 text-amber-400" />
              <h3 className="text-xl font-display-royal text-amber-200">
                Glosario Léxico e Histórico (B2)
              </h3>
            </div>
            <p className="text-xs text-stone-400 mt-1">
              Vocabulario específico de la época, instituciones y conectores discursivos ({termsList.length} términos)
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-xl transition-colors cursor-pointer"
            aria-label="Cerrar glosario"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Category filter */}
        <div className="p-4 border-b border-stone-800 bg-stone-950/40 space-y-3 shrink-0">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar por término, definición o significado en inglés..."
              className="w-full pl-9 pr-4 py-2 bg-stone-950 border border-stone-800 rounded-lg text-sm text-stone-200 placeholder:text-stone-500 focus:outline-none focus:border-amber-500/60 transition-colors"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            <Filter className="w-3.5 h-3.5 text-stone-400 shrink-0 mr-1" />
            {categories.map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-md capitalize whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-amber-600/30 text-amber-200 border border-amber-500/40 font-medium'
                    : 'text-stone-400 hover:text-stone-200 bg-stone-800/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Terms list */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-3">
          {filteredTerms.length === 0 ? (
            <div className="text-center py-12 text-stone-400">
              <p>No se encontraron términos que coincidan con la búsqueda.</p>
            </div>
          ) : (
            filteredTerms.map(item => {
              const isLearned = !!learnedTerms[item.id];
              return (
                <div
                  key={item.id}
                  className={`p-4 rounded-xl border transition-all ${
                    isLearned
                      ? 'bg-emerald-950/20 border-emerald-800/40'
                      : 'bg-stone-950/40 border-stone-800 hover:border-amber-600/30'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-display-royal text-lg text-amber-200 font-semibold">
                          {item.word}
                        </span>
                        <span className="text-xs text-stone-400 italic">
                          ({item.category})
                        </span>
                        <span className="text-xs text-amber-400/80 font-medium bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/30">
                          {item.translationEn}
                        </span>
                        {item.pronunciationTip && (
                          <span className="text-xs font-mono text-stone-400">
                            [{item.pronunciationTip}]
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-stone-300 leading-relaxed font-sans-ui mt-1">
                        {item.definition}
                      </p>
                      <p className="text-xs text-stone-400 italic font-serif-book mt-2 pl-2 border-l border-amber-600/40">
                        «{item.example}»
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => playTerm(item, e)}
                        className="p-2 text-stone-400 hover:text-amber-200 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
                        title="Escuchar pronunciación"
                        aria-label={`Pronunciar ${item.word}`}
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => toggleLearned(item.id)}
                        className={`p-2 rounded-lg transition-colors cursor-pointer ${
                          isLearned
                            ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/50'
                            : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
                        }`}
                        title={isLearned ? 'Marcado como aprendido' : 'Marcar como aprendido'}
                        aria-label={`Marcar ${item.word} como aprendido`}
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-stone-800 bg-stone-950/60 flex items-center justify-between text-xs text-stone-400 px-6 shrink-0">
          <span>
            {Object.values(learnedTerms).filter(Boolean).length} de {termsList.length} términos dominados
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg transition-colors cursor-pointer"
          >
            Cerrar Glosario
          </button>
        </div>
      </div>
    </div>
  );
};
