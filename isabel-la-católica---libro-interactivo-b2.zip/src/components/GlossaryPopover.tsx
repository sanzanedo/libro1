/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { GlossaryItem } from '../types/book';
import { Volume2, X, BookOpen } from 'lucide-react';
import { speechReader } from '../utils/audio';

interface GlossaryPopoverProps {
  item: GlossaryItem;
  onClose: () => void;
  onOpenFullGlossary?: () => void;
  position?: { x: number; y: number };
}

export const GlossaryPopover: React.FC<GlossaryPopoverProps> = ({
  item,
  onClose,
  onOpenFullGlossary,
}) => {
  const handlePronounce = (e: React.MouseEvent) => {
    e.stopPropagation();
    speechReader.speakText({
      text: `${item.word}. ${item.definition}`,
      rate: 0.9,
    });
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-md bg-stone-900 border border-amber-600/30 rounded-xl p-5 shadow-2xl text-stone-100 animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-stone-800 pb-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-xl font-display-royal text-amber-200 capitalize">
                {item.word}
              </h4>
              <button
                type="button"
                onClick={handlePronounce}
                title="Escuchar pronunciación"
                className="p-1.5 text-amber-400/80 hover:text-amber-200 hover:bg-amber-950/50 rounded-lg transition-colors cursor-pointer"
                aria-label={`Pronunciar ${item.word}`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-center gap-2 text-xs text-stone-400 mt-1">
              <span className="italic">{item.category}</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-300/80 font-medium">{item.translationEn}</span>
              {item.pronunciationTip && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-stone-400 text-[11px]">{item.pronunciationTip}</span>
                </>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Cerrar glosario"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Definition & Example */}
        <div className="space-y-3 text-sm text-stone-200">
          <div>
            <p className="text-xs uppercase tracking-wider text-amber-500/80 font-sans-ui font-medium mb-1">
              Definición (Nivel B2)
            </p>
            <p className="leading-relaxed font-sans-ui text-stone-300">
              {item.definition}
            </p>
          </div>

          <div className="bg-stone-950/60 rounded-lg p-3 border border-stone-800/80">
            <p className="text-xs uppercase tracking-wider text-stone-400 font-sans-ui font-medium mb-1">
              Ejemplo en contexto histórico
            </p>
            <p className="font-serif-book italic text-stone-300 leading-relaxed">
              «{item.example}»
            </p>
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-4 pt-3 border-t border-stone-800 flex items-center justify-between text-xs">
          <span className="text-stone-400">
            Vocabulario DELE B2
          </span>
          {onOpenFullGlossary && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenFullGlossary();
              }}
              className="inline-flex items-center gap-1.5 text-amber-300 hover:text-amber-200 transition-colors font-medium cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5" />
              Ver Glosario Completo
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
