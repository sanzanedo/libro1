/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BOOK_PAGES } from '../data/bookContent';
import { X, BookOpen, ChevronRight, Bookmark } from 'lucide-react';

interface ChaptersDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentPageIndex: number;
  onSelectPage: (index: number) => void;
}

export const ChaptersDrawer: React.FC<ChaptersDrawerProps> = ({
  isOpen,
  onClose,
  currentPageIndex,
  onSelectPage,
}) => {
  if (!isOpen) return null;

  // Filter distinct chapters or significant pages
  const chapterEntries = BOOK_PAGES.filter((p, i) => {
    // Show cover, TOC, first page of each chapter, activities and glossary
    if (i === 0 || i === 1 || i === 2) return true;
    return i % 2 !== 0; // odd pages start the spreads
  });

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm h-full bg-stone-900 border-l border-amber-600/30 p-6 flex flex-col justify-between text-stone-100 shadow-2xl animate-in slide-in-from-right duration-200"
        onClick={e => e.stopPropagation()}
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-4">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-amber-400" />
              <h3 className="text-xl font-display-royal text-amber-200">
                Índice de Capítulos
              </h3>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
              aria-label="Cerrar índice"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-xs text-stone-400 font-sans-ui mb-4">
            Seleccione una sección para abrir el libro directamente en esas páginas.
          </p>

          {/* Chapter list */}
          <div className="space-y-1.5 overflow-y-auto max-h-[calc(100vh-180px)] pr-1">
            {chapterEntries.map(entry => {
              const actualIdx = BOOK_PAGES.findIndex(p => p.id === entry.id);
              const isSelected = currentPageIndex === actualIdx || (currentPageIndex % 2 === 1 && currentPageIndex === actualIdx) || (currentPageIndex % 2 === 0 && actualIdx === currentPageIndex - 1);

              return (
                <button
                  key={entry.id}
                  type="button"
                  onClick={() => {
                    onSelectPage(actualIdx);
                    onClose();
                  }}
                  className={`w-full text-left p-3 rounded-xl border flex items-center justify-between group transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-amber-950/60 border-amber-500/50 text-amber-200 font-medium'
                      : 'bg-stone-950/40 border-stone-800/80 hover:border-amber-600/30 text-stone-300'
                  }`}
                >
                  <div className="space-y-0.5 truncate pr-2">
                    <span className="text-[10px] uppercase tracking-wider text-amber-500/80 font-sans-ui block">
                      Pág. {entry.pageNumber}
                    </span>
                    <span className="text-xs md:text-sm font-serif-book block truncate group-hover:text-amber-100">
                      {entry.chapterTitle}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-stone-500 group-hover:text-amber-400 shrink-0 transition-transform group-hover:translate-x-0.5" />
                </button>
              );
            })}
          </div>
        </div>

        <div className="pt-3 border-t border-stone-800 text-xs text-stone-500 text-center font-sans-ui">
          Isabel la Católica · Crónica Histórica B2
        </div>
      </div>
    </div>
  );
};
