/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { BookPage, FontSize, GlossaryItem, PaperTheme } from '../types/book';
import { BOOK_PAGES } from '../data/bookContent';
import { BookPageContent } from './BookPageContent';
import { ChevronLeft, ChevronRight, Bookmark } from 'lucide-react';
import { pageAudio } from '../utils/audio';

interface BookViewerProps {
  currentPageIndex: number; // 0-based index in BOOK_PAGES
  onPageChange: (newIndex: number) => void;
  fontSize: FontSize;
  paperTheme: PaperTheme;
  pageSoundEnabled: boolean;
  activeReadingId: string | null;
  onTermClick: (term: GlossaryItem) => void;
  onReadParagraph: (text: string, id: string) => void;
  onOpenQuiz: () => void;
  onOpenGlossary: () => void;
}

export const BookViewer: React.FC<BookViewerProps> = ({
  currentPageIndex,
  onPageChange,
  fontSize,
  paperTheme,
  pageSoundEnabled,
  activeReadingId,
  onTermClick,
  onReadParagraph,
  onOpenQuiz,
  onOpenGlossary,
}) => {
  const [bookmarks, setBookmarks] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('isabel_b2_bookmarks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [turnDirection, setTurnDirection] = useState<'next' | 'prev' | null>(null);
  const [isAnimating, setIsAnimating] = useState(false);

  // In two-page spread:
  // If currentPageIndex is 0 (Cover, page 1), we show just page 1 or page 1 on right.
  // For other pages, we align to even/odd spread:
  // Spread: Left page is index (2k - 1), Right page is index 2k.
  const isCover = currentPageIndex === 0;
  const leftPageIndex = isCover ? null : (currentPageIndex % 2 === 1 ? currentPageIndex : currentPageIndex - 1);
  const rightPageIndex = isCover ? 0 : (leftPageIndex !== null ? leftPageIndex + 1 : null);

  const leftPage: BookPage | null = leftPageIndex !== null && leftPageIndex >= 0 && leftPageIndex < BOOK_PAGES.length ? BOOK_PAGES[leftPageIndex] : null;
  const rightPage: BookPage | null = rightPageIndex !== null && rightPageIndex >= 0 && rightPageIndex < BOOK_PAGES.length ? BOOK_PAGES[rightPageIndex] : null;

  const toggleBookmark = (pageNumber: number) => {
    setBookmarks(prev => {
      const exists = prev.includes(pageNumber);
      const updated = exists ? prev.filter(p => p !== pageNumber) : [...prev, pageNumber];
      try {
        localStorage.setItem('isabel_b2_bookmarks', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  };

  const flipNext = useCallback(() => {
    if (isAnimating) return;
    let nextIndex: number;
    if (isCover) {
      nextIndex = 1; // Page 2 & 3
    } else {
      nextIndex = Math.min(currentPageIndex + 2, BOOK_PAGES.length - 1);
    }

    if (nextIndex !== currentPageIndex) {
      if (pageSoundEnabled) {
        pageAudio.playPaperTurn();
      }
      setTurnDirection('next');
      setIsAnimating(true);
      setTimeout(() => {
        onPageChange(nextIndex);
        setIsAnimating(false);
        setTurnDirection(null);
      }, 180);
    }
  }, [currentPageIndex, isCover, isAnimating, onPageChange, pageSoundEnabled]);

  const flipPrev = useCallback(() => {
    if (isAnimating) return;
    let prevIndex: number;
    if (currentPageIndex <= 1) {
      prevIndex = 0;
    } else {
      prevIndex = Math.max(currentPageIndex - 2, 0);
    }

    if (prevIndex !== currentPageIndex) {
      if (pageSoundEnabled) {
        pageAudio.playPaperTurn();
      }
      setTurnDirection('prev');
      setIsAnimating(true);
      setTimeout(() => {
        onPageChange(prevIndex);
        setIsAnimating(false);
        setTurnDirection(null);
      }, 180);
    }
  }, [currentPageIndex, isAnimating, onPageChange, pageSoundEnabled]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        flipNext();
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        flipPrev();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [flipNext, flipPrev]);

  // Get paper theme styling
  const getPaperBg = () => {
    switch (paperTheme) {
      case 'sepia': return 'paper-sepia text-stone-900 border-amber-900/20';
      case 'white': return 'paper-white text-stone-900 border-stone-200';
      case 'night': return 'paper-night text-stone-100 border-stone-800';
      case 'parchment':
      default:
        return 'paper-parchment text-stone-950 border-amber-800/30';
    }
  };

  const paperClasses = getPaperBg();

  return (
    <div className="relative w-full max-w-6xl mx-auto flex flex-col items-center select-none">
      {/* Physical Book Exterior Container */}
      <div className="relative w-full p-2 md:p-6 bg-stone-950 rounded-2xl md:rounded-3xl shadow-[0_25px_60px_-15px_rgba(0,0,0,0.85)] border border-amber-900/30">
        
        {/* Ornate corner embellishments for classical luxury book aesthetic */}
        <div className="hidden md:block absolute top-3 left-3 w-8 h-8 border-t-2 border-l-2 border-amber-600/40 rounded-tl-lg pointer-events-none" />
        <div className="hidden md:block absolute top-3 right-3 w-8 h-8 border-t-2 border-r-2 border-amber-600/40 rounded-tr-lg pointer-events-none" />
        <div className="hidden md:block absolute bottom-3 left-3 w-8 h-8 border-b-2 border-l-2 border-amber-600/40 rounded-bl-lg pointer-events-none" />
        <div className="hidden md:block absolute bottom-3 right-3 w-8 h-8 border-b-2 border-r-2 border-amber-600/40 rounded-br-lg pointer-events-none" />

        {/* The Open Book Surface */}
        <div className="relative w-full min-h-[580px] md:min-h-[640px] flex rounded-xl overflow-hidden shadow-2xl book-perspective">
          
          {/* DESKTOP TWO-PAGE SPREAD VIEW */}
          {isCover ? (
            /* Cover Mode: Full Width Single Majestic Page */
            <div className={`w-full min-h-[580px] md:min-h-[640px] ${paperClasses} transition-opacity duration-200 ${isAnimating ? 'opacity-70 scale-[0.99]' : 'opacity-100 scale-100'}`}>
              <BookPageContent
                page={BOOK_PAGES[0]}
                fontSize={fontSize}
                paperTheme={paperTheme}
                activeReadingId={activeReadingId}
                onTermClick={onTermClick}
                onReadParagraph={onReadParagraph}
                isBookmarked={bookmarks.includes(1)}
                onToggleBookmark={() => toggleBookmark(1)}
                onNavigateToPage={(num) => onPageChange(num - 1)}
                onOpenQuiz={onOpenQuiz}
                onOpenGlossary={onOpenGlossary}
              />
            </div>
          ) : (
            /* Two-Page Spread Mode (or Single Page on Mobile) */
            <div className="w-full flex flex-col md:flex-row relative">
              
              {/* Left Page (Hidden on narrow mobile screens) */}
              <div className={`hidden md:block md:w-1/2 min-h-[640px] border-r border-stone-300/60 dark:border-stone-800 ${paperClasses} relative ${isAnimating && turnDirection === 'prev' ? 'brightness-95' : ''}`}>
                {/* Center spine shadow (left side) */}
                <div className="absolute top-0 right-0 bottom-0 w-8 book-spine-left pointer-events-none z-10" />
                
                {leftPage ? (
                  <BookPageContent
                    page={leftPage}
                    fontSize={fontSize}
                    paperTheme={paperTheme}
                    activeReadingId={activeReadingId}
                    onTermClick={onTermClick}
                    onReadParagraph={onReadParagraph}
                    isBookmarked={bookmarks.includes(leftPage.pageNumber)}
                    onToggleBookmark={() => toggleBookmark(leftPage.pageNumber)}
                    onNavigateToPage={(num) => onPageChange(num - 1)}
                    onOpenQuiz={onOpenQuiz}
                    onOpenGlossary={onOpenGlossary}
                  />
                ) : (
                  <div className="h-full flex items-center justify-center p-8 text-stone-400 font-serif-book italic">
                    Página en blanco
                  </div>
                )}
              </div>

              {/* Right Page (or Only Page on Mobile) */}
              <div className={`w-full md:w-1/2 min-h-[580px] md:min-h-[640px] ${paperClasses} relative ${isAnimating && turnDirection === 'next' ? 'brightness-95' : ''}`}>
                {/* Center spine shadow (right side) */}
                <div className="hidden md:block absolute top-0 left-0 bottom-0 w-8 book-spine-right pointer-events-none z-10" />

                {rightPage ? (
                  <BookPageContent
                    page={rightPage}
                    fontSize={fontSize}
                    paperTheme={paperTheme}
                    activeReadingId={activeReadingId}
                    onTermClick={onTermClick}
                    onReadParagraph={onReadParagraph}
                    isBookmarked={bookmarks.includes(rightPage.pageNumber)}
                    onToggleBookmark={() => toggleBookmark(rightPage.pageNumber)}
                    onNavigateToPage={(num) => onPageChange(num - 1)}
                    onOpenQuiz={onOpenQuiz}
                    onOpenGlossary={onOpenGlossary}
                  />
                ) : (
                  <div className="h-full flex items-center justify-center p-8 text-stone-400 font-serif-book italic">
                    Fin del volumen
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Lateral Click Zones for intuitive page turning */}
          <button
            type="button"
            onClick={flipPrev}
            disabled={currentPageIndex === 0}
            className="absolute left-0 top-0 bottom-0 w-12 md:w-16 flex items-center justify-start pl-2 text-stone-500/0 hover:text-stone-800 dark:hover:text-amber-200 hover:bg-gradient-to-r hover:from-black/10 hover:to-transparent transition-all disabled:opacity-0 disabled:pointer-events-none cursor-pointer z-20"
            title="Página anterior (Tecla ←)"
            aria-label="Página anterior"
          >
            <div className="p-2 rounded-full bg-stone-900/60 text-amber-200 shadow-md backdrop-blur-xs">
              <ChevronLeft className="w-5 h-5" />
            </div>
          </button>

          <button
            type="button"
            onClick={flipNext}
            disabled={currentPageIndex >= BOOK_PAGES.length - 1}
            className="absolute right-0 top-0 bottom-0 w-12 md:w-16 flex items-center justify-end pr-2 text-stone-500/0 hover:text-stone-800 dark:hover:text-amber-200 hover:bg-gradient-to-l hover:from-black/10 hover:to-transparent transition-all disabled:opacity-0 disabled:pointer-events-none cursor-pointer z-20"
            title="Página siguiente (Tecla →)"
            aria-label="Página siguiente"
          >
            <div className="p-2 rounded-full bg-stone-900/60 text-amber-200 shadow-md backdrop-blur-xs">
              <ChevronRight className="w-5 h-5" />
            </div>
          </button>
        </div>

        {/* Bottom Page Navigation Strip */}
        <div className="mt-4 pt-3 border-t border-stone-800/80 flex items-center justify-between text-xs text-stone-400 px-2">
          {/* Prev button */}
          <button
            type="button"
            onClick={flipPrev}
            disabled={currentPageIndex === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-800 hover:border-amber-600/40 hover:text-stone-200 disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Página Anterior</span>
          </button>

          {/* Page scrubber / indicator */}
          <div className="flex items-center gap-3">
            <span className="font-mono text-amber-400 font-medium">
              {isCover
                ? 'Portada'
                : `Págs. ${leftPage?.pageNumber || 1} - ${rightPage?.pageNumber || 2} de ${BOOK_PAGES.length}`}
            </span>
            <div className="hidden md:flex items-center gap-1">
              {BOOK_PAGES.map((p, idx) => {
                // Show condensed dots
                if (idx % 2 !== 0 && idx !== 0 && idx !== BOOK_PAGES.length - 1) return null;
                const isActive = idx === currentPageIndex || (idx === leftPageIndex) || (idx === rightPageIndex);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => onPageChange(idx)}
                    title={`Ir a página ${p.pageNumber}: ${p.chapterTitle}`}
                    className={`w-2 h-2 rounded-full transition-all cursor-pointer ${
                      isActive
                        ? 'bg-amber-400 scale-125'
                        : 'bg-stone-700 hover:bg-stone-500'
                    }`}
                  />
                );
              })}
            </div>
          </div>

          {/* Next button */}
          <button
            type="button"
            onClick={flipNext}
            disabled={currentPageIndex >= BOOK_PAGES.length - 1}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-stone-800 hover:border-amber-600/40 hover:text-stone-200 disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
          >
            <span className="hidden sm:inline">Página Siguiente</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
