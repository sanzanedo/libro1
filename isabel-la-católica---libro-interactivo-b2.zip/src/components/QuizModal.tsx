/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { QUIZ_QUESTIONS } from '../data/bookContent';
import { QuizQuestion } from '../types/book';
import { CheckCircle2, XCircle, Award, RotateCcw, X, GraduationCap } from 'lucide-react';

interface QuizModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({ isOpen, onClose }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [showExplanation, setShowExplanation] = useState<Record<string, boolean>>({});
  const [completed, setCompleted] = useState(false);

  if (!isOpen) return null;

  const currentQ: QuizQuestion = QUIZ_QUESTIONS[currentIdx];
  const userChoice = selectedAnswers[currentQ.id];
  const isAnswered = userChoice !== undefined;
  const isCorrect = isAnswered && userChoice === currentQ.correctIndex;

  const handleSelect = (optIndex: number) => {
    if (isAnswered) return;
    setSelectedAnswers(prev => ({ ...prev, [currentQ.id]: optIndex }));
    setShowExplanation(prev => ({ ...prev, [currentQ.id]: true }));
  };

  const handleNext = () => {
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx(prev => prev + 1);
    } else {
      setCompleted(true);
    }
  };

  const handlePrev = () => {
    if (currentIdx > 0) {
      setCurrentIdx(prev => prev - 1);
    }
  };

  const handleReset = () => {
    setSelectedAnswers({});
    setShowExplanation({});
    setCurrentIdx(0);
    setCompleted(false);
  };

  const totalCorrect = Object.entries(selectedAnswers).reduce((acc, [qid, ans]) => {
    const q = QUIZ_QUESTIONS.find(item => item.id === qid);
    return acc + (q && q.correctIndex === ans ? 1 : 0);
  }, 0);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-stone-900 border border-amber-600/30 rounded-2xl shadow-2xl p-6 text-stone-100 flex flex-col max-h-[90vh] overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-amber-400" />
            <h3 className="text-xl font-display-royal text-amber-200">
              Cuestionario de Comprensión Lectora B2
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Cerrar cuestionario"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!completed ? (
          <div className="flex-1 overflow-y-auto pr-1 space-y-4">
            {/* Progress indicator */}
            <div className="flex items-center justify-between text-xs text-stone-400">
              <span>Pregunta {currentIdx + 1} de {QUIZ_QUESTIONS.length}</span>
              <span>Aciertos: {totalCorrect} / {Object.keys(selectedAnswers).length}</span>
            </div>
            <div className="w-full h-1.5 bg-stone-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all duration-300"
                style={{ width: `${((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
              />
            </div>

            {/* Question Text */}
            <div className="pt-2">
              <h4 className="text-base md:text-lg font-serif-book font-medium text-amber-100 leading-snug">
                {currentQ.question}
              </h4>
            </div>

            {/* Options */}
            <div className="space-y-2 pt-2">
              {currentQ.options.map((option, idx) => {
                const isSelected = userChoice === idx;
                const isRight = currentQ.correctIndex === idx;

                let btnStyle = 'bg-stone-950/60 border-stone-800 hover:border-amber-600/40 text-stone-200';
                if (isAnswered) {
                  if (isRight) {
                    btnStyle = 'bg-emerald-950/40 border-emerald-500/60 text-emerald-200 font-medium';
                  } else if (isSelected && !isRight) {
                    btnStyle = 'bg-red-950/40 border-red-500/60 text-red-200';
                  } else {
                    btnStyle = 'opacity-60 bg-stone-950/30 border-stone-800 text-stone-400';
                  }
                }

                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelect(idx)}
                    disabled={isAnswered}
                    className={`w-full text-left p-3.5 rounded-xl border text-sm transition-all flex items-start gap-3 cursor-pointer ${btnStyle}`}
                  >
                    <span className="font-mono text-xs text-stone-400 mt-0.5 shrink-0">
                      {String.fromCharCode(65 + idx)})
                    </span>
                    <span className="flex-1 font-sans-ui">{option}</span>
                    {isAnswered && isRight && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    )}
                    {isAnswered && isSelected && !isRight && (
                      <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation box */}
            {isAnswered && showExplanation[currentQ.id] && (
              <div className={`p-4 rounded-xl border text-xs leading-relaxed font-sans-ui ${
                isCorrect
                  ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-200'
                  : 'bg-amber-950/30 border-amber-800/40 text-amber-200'
              }`}>
                <p className="font-semibold mb-1">
                  {isCorrect ? '¡Excelente!' : 'Respuesta Incorrecta:'}
                </p>
                <p>{currentQ.explanation}</p>
              </div>
            )}
          </div>
        ) : (
          /* Completed Score Screen */
          <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Award className="w-8 h-8" />
            </div>
            <h4 className="text-2xl font-display-royal font-semibold text-amber-200">
              ¡Cuestionario Completado!
            </h4>
            <p className="text-stone-300 text-sm max-w-md">
              Ha obtenido <span className="text-amber-400 font-bold">{totalCorrect}</span> de <span className="font-bold">{QUIZ_QUESTIONS.length}</span> aciertos en la evaluación de comprensión sobre Isabel la Católica.
            </p>
            <div className="p-4 bg-stone-950/60 rounded-xl border border-stone-800 text-xs text-stone-400 max-w-sm">
              {totalCorrect >= 5 ? (
                <p className="text-emerald-300 font-medium">
                  Nivel de dominio B2 destacado. Capacidad sobresaliente para sintetizar hechos históricos y vocabulario contextual.
                </p>
              ) : (
                <p className="text-amber-300 font-medium">
                  Buen intento. Le recomendamos repasar los capítulos 3 y 8 junto con las definiciones del glosario.
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-amber-800 hover:bg-amber-700 text-amber-100 rounded-xl font-medium text-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              Repetir Cuestionario
            </button>
          </div>
        )}

        {/* Footer Navigation */}
        {!completed && (
          <div className="border-t border-stone-800 pt-3 mt-3 flex items-center justify-between text-xs">
            <button
              type="button"
              onClick={handlePrev}
              disabled={currentIdx === 0}
              className="px-3 py-1.5 rounded-lg border border-stone-800 text-stone-300 hover:bg-stone-800 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition-colors"
            >
              Anterior
            </button>

            <button
              type="button"
              onClick={handleNext}
              disabled={!isAnswered}
              className="px-4 py-1.5 rounded-lg bg-amber-800 hover:bg-amber-700 text-amber-100 font-medium disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-colors"
            >
              {currentIdx === QUIZ_QUESTIONS.length - 1 ? 'Ver Resultado' : 'Siguiente'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
