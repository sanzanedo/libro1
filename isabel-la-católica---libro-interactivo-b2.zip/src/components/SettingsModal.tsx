/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { FontSize, PaperTheme } from '../types/book';
import { X, Sliders, Volume2, Type, Palette } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  fontSize: FontSize;
  onFontSizeChange: (size: FontSize) => void;
  paperTheme: PaperTheme;
  onPaperThemeChange: (theme: PaperTheme) => void;
  pageSoundEnabled: boolean;
  onTogglePageSound: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  fontSize,
  onFontSizeChange,
  paperTheme,
  onPaperThemeChange,
  pageSoundEnabled,
  onTogglePageSound,
}) => {
  if (!isOpen) return null;

  const fontSizes: { id: FontSize; label: string }[] = [
    { id: 'sm', label: 'Estándar (14px)' },
    { id: 'md', label: 'Mediano (16px)' },
    { id: 'lg', label: 'Grande (18px)' },
    { id: 'xl', label: 'Muy grande (20px)' },
  ];

  const paperThemes: { id: PaperTheme; label: string; previewBg: string; textClass: string }[] = [
    { id: 'parchment', label: 'Pergamino Real', previewBg: 'bg-[#F8F5EE]', textClass: 'text-stone-900' },
    { id: 'sepia', label: 'Sepia Suave', previewBg: 'bg-[#F4EEDF]', textClass: 'text-stone-900' },
    { id: 'white', label: 'Blanco Editorial', previewBg: 'bg-[#FFFFFF]', textClass: 'text-stone-900' },
    { id: 'night', label: 'Noche Palaciega', previewBg: 'bg-[#1A1917]', textClass: 'text-stone-200' },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-stone-900 border border-amber-600/30 rounded-2xl p-6 shadow-2xl text-stone-100 space-y-5"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h3 className="text-xl font-display-royal text-amber-200">
              Preferencias de Lectura
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
            aria-label="Cerrar ajustes"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Font Size */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-400">
            <Type className="w-4 h-4 text-amber-400" />
            <span>Tamaño de Tipografía</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {fontSizes.map(f => (
              <button
                key={f.id}
                type="button"
                onClick={() => onFontSizeChange(f.id)}
                className={`py-2 px-3 text-xs rounded-xl border transition-colors cursor-pointer text-left ${
                  fontSize === f.id
                    ? 'bg-amber-950/60 border-amber-500/60 text-amber-200 font-medium'
                    : 'bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Paper Theme */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-400">
            <Palette className="w-4 h-4 text-amber-400" />
            <span>Textura y Tono de Papel</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {paperThemes.map(t => (
              <button
                key={t.id}
                type="button"
                onClick={() => onPaperThemeChange(t.id)}
                className={`p-2.5 rounded-xl border flex items-center gap-2.5 transition-colors cursor-pointer ${
                  paperTheme === t.id
                    ? 'border-amber-500 bg-amber-950/40 text-amber-200'
                    : 'border-stone-800 bg-stone-950 text-stone-400 hover:text-stone-200'
                }`}
              >
                <div className={`w-5 h-5 rounded-md border border-stone-700/50 ${t.previewBg}`} />
                <span className="text-xs font-medium">{t.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Sound toggle */}
        <div className="pt-2 border-t border-stone-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-amber-400" />
            <span className="text-sm text-stone-200">Efecto sonoro al pasar página</span>
          </div>
          <button
            type="button"
            onClick={onTogglePageSound}
            className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
              pageSoundEnabled ? 'bg-amber-600' : 'bg-stone-800'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                pageSoundEnabled ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* Close Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 bg-amber-800 hover:bg-amber-700 text-amber-100 rounded-xl text-sm font-medium transition-colors cursor-pointer"
          >
            Aceptar
          </button>
        </div>
      </div>
    </div>
  );
};
