/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface TopNavProps {
  onGoToCover: () => void;
  onOpenChapters: () => void;
  onOpenGlossary: () => void;
  onOpenQuiz: () => void;
  onOpenSettings: () => void;
  onStartReading: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  onGoToCover,
  onOpenChapters,
  onOpenGlossary,
  onOpenQuiz,
  onOpenSettings,
  onStartReading,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-amber-900/40 bg-stone-950/80 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark in display face */}
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          onGoToCover();
        }}
        className="text-lg md:text-xl font-display-royal font-bold tracking-wide text-amber-200 hover:text-amber-100 transition-colors whitespace-nowrap shrink-0"
      >
        Isabel la Católica
      </a>

      {/* Zone 2: 4–5 clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-300">
        <a
          href="#portada"
          onClick={(e) => {
            e.preventDefault();
            onGoToCover();
          }}
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          Portada
        </a>
        <a
          href="#capitulos"
          onClick={(e) => {
            e.preventDefault();
            onOpenChapters();
          }}
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          Capítulos
        </a>
        <a
          href="#glosario"
          onClick={(e) => {
            e.preventDefault();
            onOpenGlossary();
          }}
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          Glosario B2
        </a>
        <a
          href="#evaluacion"
          onClick={(e) => {
            e.preventDefault();
            onOpenQuiz();
          }}
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          Evaluación
        </a>
        <a
          href="#ajustes"
          onClick={(e) => {
            e.preventDefault();
            onOpenSettings();
          }}
          className="hover:text-amber-200 transition-colors whitespace-nowrap shrink-0"
        >
          Preferencias
        </a>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          type="button"
          onClick={onStartReading}
          className="px-4 py-2 text-xs font-semibold text-amber-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm"
        >
          Leer en Voz
        </button>
      </div>
    </header>
  );
};
