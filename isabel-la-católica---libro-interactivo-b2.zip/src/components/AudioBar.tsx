/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Play, Pause, Square, Volume2, Settings2, Sparkles, VolumeX } from 'lucide-react';
import { speechReader } from '../utils/audio';

interface AudioBarProps {
  onPlayCurrentPage: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  isPlaying: boolean;
  isPaused: boolean;
  activeReadingId: string | null;
  speechRate: number;
  onSpeedChange: (rate: number) => void;
  pageSoundEnabled: boolean;
  onTogglePageSound: () => void;
}

export const AudioBar: React.FC<AudioBarProps> = ({
  onPlayCurrentPage,
  onPause,
  onResume,
  onStop,
  isPlaying,
  isPaused,
  speechRate,
  onSpeedChange,
  pageSoundEnabled,
  onTogglePageSound,
}) => {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceName, setSelectedVoiceName] = useState<string>('');
  const [showVoiceMenu, setShowVoiceMenu] = useState(false);

  useEffect(() => {
    const updateVoices = () => {
      const spanishVoices = speechReader.getSpanishVoices();
      setVoices(spanishVoices);
      const current = speechReader.getSelectedVoice();
      if (current) {
        setSelectedVoiceName(current.name);
      }
    };

    updateVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  const handleVoiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const voice = voices.find(v => v.name === e.target.value);
    if (voice) {
      speechReader.setSelectedVoice(voice);
      setSelectedVoiceName(voice.name);
    }
  };

  const speedOptions = [0.8, 1.0, 1.2];

  return (
    <div className="bg-stone-900/90 backdrop-blur-md border border-amber-600/30 rounded-xl px-4 py-2.5 shadow-xl flex items-center justify-between gap-4 text-stone-200">
      {/* Playback Controls */}
      <div className="flex items-center gap-2">
        {!isPlaying ? (
          <button
            type="button"
            onClick={onPlayCurrentPage}
            className="flex items-center gap-2 px-3 py-1.5 bg-amber-700 hover:bg-amber-600 text-amber-50 rounded-lg text-xs font-medium shadow-sm transition-colors cursor-pointer"
            title="Leer página actual en voz alta"
            aria-label="Escuchar página actual"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">Lectura en voz</span>
          </button>
        ) : isPaused ? (
          <button
            type="button"
            onClick={onResume}
            className="flex items-center gap-2 px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-amber-50 rounded-lg text-xs font-medium shadow-sm transition-colors cursor-pointer"
            title="Reanudar narración"
            aria-label="Reanudar lectura"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">Continuar</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={onPause}
            className="flex items-center gap-2 px-3 py-1.5 bg-amber-900/80 hover:bg-amber-800 text-amber-200 rounded-lg text-xs font-medium transition-colors cursor-pointer"
            title="Pausar narración"
            aria-label="Pausar lectura"
          >
            <Pause className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">Pausar</span>
          </button>
        )}

        {isPlaying && (
          <button
            type="button"
            onClick={onStop}
            className="p-1.5 text-stone-400 hover:text-stone-100 hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
            title="Detener lectura"
            aria-label="Detener lectura"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
          </button>
        )}

        {isPlaying && !isPaused && (
          <span className="text-[11px] text-amber-400 font-sans-ui hidden md:flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5" />
            Narrando...
          </span>
        )}
      </div>

      {/* Speed & Audio Options */}
      <div className="flex items-center gap-3 text-xs">
        {/* Speed presets */}
        <div className="flex items-center gap-1 bg-stone-950/60 p-0.5 rounded-lg border border-stone-800">
          {speedOptions.map(s => (
            <button
              key={s}
              type="button"
              onClick={() => onSpeedChange(s)}
              className={`px-2 py-0.5 rounded font-mono transition-colors cursor-pointer ${
                speechRate === s
                  ? 'bg-amber-700 text-amber-100 font-medium'
                  : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              {s}x
            </button>
          ))}
        </div>

        {/* Voice selector */}
        {voices.length > 0 && (
          <div className="hidden lg:flex items-center gap-1.5">
            <select
              value={selectedVoiceName}
              onChange={handleVoiceChange}
              className="bg-stone-950 border border-stone-800 text-stone-300 text-xs rounded-lg px-2 py-1 max-w-[140px] truncate focus:outline-none focus:border-amber-600/50 cursor-pointer"
              title="Voz de narración"
            >
              {voices.map(v => (
                <option key={v.name} value={v.name}>
                  {v.name.replace(/Google|Microsoft|Apple|Desktop|Natural/gi, '').trim() || v.name} ({v.lang})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Page turn sound toggle */}
        <button
          type="button"
          onClick={onTogglePageSound}
          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
            pageSoundEnabled
              ? 'text-amber-400 hover:bg-stone-800'
              : 'text-stone-500 hover:text-stone-300'
          }`}
          title={pageSoundEnabled ? 'Sonido de pasar página activado' : 'Sonido de página desactivado'}
          aria-label="Alternar sonido de pasar página"
        >
          {pageSoundEnabled ? (
            <Sparkles className="w-4 h-4" />
          ) : (
            <VolumeX className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
};
