/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookPage, FontSize, GlossaryItem, PaperTheme } from '../types/book';
import { GLOSSARY } from '../data/bookContent';
import { Sparkles, BookOpen, Volume2, Bookmark, GraduationCap } from 'lucide-react';

interface BookPageContentProps {
  page: BookPage;
  fontSize: FontSize;
  paperTheme: PaperTheme;
  activeReadingId: string | null;
  onTermClick: (term: GlossaryItem) => void;
  onReadParagraph?: (text: string, id: string) => void;
  isBookmarked?: boolean;
  onToggleBookmark?: () => void;
  onNavigateToPage?: (pageNum: number) => void;
  onOpenQuiz?: () => void;
  onOpenGlossary?: () => void;
}

export const BookPageContent: React.FC<BookPageContentProps> = ({
  page,
  fontSize,
  paperTheme,
  activeReadingId,
  onTermClick,
  onReadParagraph,
  isBookmarked,
  onToggleBookmark,
  onNavigateToPage,
  onOpenQuiz,
  onOpenGlossary,
}) => {
  const getFontSizeClass = (size: FontSize) => {
    switch (size) {
      case 'sm': return 'text-[14px] leading-relaxed';
      case 'lg': return 'text-[18px] leading-relaxed';
      case 'xl': return 'text-[20px] leading-loose';
      case 'md':
      default:
        return 'text-[16px] leading-relaxed';
    }
  };

  // Function to highlight glossary terms in paragraph text
  const renderInteractiveText = (text: string, glossaryIds?: string[]) => {
    if (!glossaryIds || glossaryIds.length === 0) {
      return text;
    }

    // Sort terms by word length descending so longer compound phrases like "Capitulaciones de Santa Fe" or "Santa Hermandad" or "bula papal" match first
    const termsToMatch = glossaryIds
      .map(id => GLOSSARY[id])
      .filter(Boolean)
      .sort((a, b) => b.word.length - a.word.length);

    if (termsToMatch.length === 0) return text;

    // Build regex pattern matching either exact word or common plural/gender variations
    const pattern = new RegExp(
      `\\b(${termsToMatch.map(t => escapeRegExp(t.word)).join('|')})([a-zñáéíóú]*)?`,
      'gi'
    );

    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = pattern.exec(text)) !== null) {
      const matchIndex = match.index;
      if (matchIndex > lastIndex) {
        parts.push(text.substring(lastIndex, matchIndex));
      }

      const fullMatchedText = match[0];
      const baseWord = match[1].toLowerCase();
      const termItem = termsToMatch.find(t => t.word.toLowerCase() === baseWord) || termsToMatch[0];

      parts.push(
        <button
          key={`${matchIndex}-${fullMatchedText}`}
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onTermClick(termItem);
          }}
          className="group inline-flex items-baseline font-medium border-b border-dashed border-amber-600 hover:border-amber-700 dark:border-amber-400 dark:hover:border-amber-300 text-amber-900 dark:text-amber-300 hover:bg-amber-500/10 transition-colors cursor-pointer rounded-xs px-0.5"
          title={`Ver glosario B2: ${termItem.word}`}
          aria-label={`Glosario: ${termItem.word}`}
        >
          <span>{fullMatchedText}</span>
          <span className="text-[10px] ml-0.5 opacity-60 group-hover:opacity-100 font-sans-ui text-amber-600 dark:text-amber-400">ℹ</span>
        </button>
      );

      lastIndex = matchIndex + fullMatchedText.length;
    }

    if (lastIndex < text.length) {
      parts.push(text.substring(lastIndex));
    }

    return parts;
  };

  const isDarkPaper = paperTheme === 'night';

  // Handle Cover Page specially
  if (page.type === 'cover') {
    return (
      <div className="h-full flex flex-col justify-between p-6 md:p-10 select-text">
        <div className="text-center space-y-2 border-b border-amber-600/30 pb-4">
          <p className="text-xs uppercase tracking-widest font-sans-ui text-amber-700 dark:text-amber-400 font-semibold">
            Crónica Histórica · Nivel B2 (MCER)
          </p>
          <h1 className="text-2xl md:text-4xl font-display-royal font-bold text-amber-950 dark:text-amber-100 tracking-wide">
            {page.paragraphs?.[0]?.text || 'ISABEL LA CATÓLICA'}
          </h1>
          <p className="text-xs md:text-sm font-serif-book italic text-stone-600 dark:text-stone-300 max-w-md mx-auto">
            {page.paragraphs?.[1]?.text}
          </p>
        </div>

        {page.image && (
          <div className="my-auto py-4 flex flex-col items-center">
            <div className="relative p-2 bg-gradient-to-b from-amber-700/20 via-amber-900/10 to-amber-700/20 rounded-xl shadow-lg border border-amber-600/30 max-w-xs md:max-w-sm">
              <img
                src={page.image.src}
                alt={page.image.alt}
                className="w-full h-auto max-h-[340px] object-cover rounded-lg shadow-inner"
                referrerPolicy="no-referrer"
              />
            </div>
            <p className="text-[11px] text-stone-500 dark:text-stone-400 font-serif-book italic mt-3 text-center max-w-xs">
              {page.image.caption}
            </p>
          </div>
        )}

        <div className="text-center pt-3 border-t border-amber-600/20 space-y-3">
          <p className="text-xs font-sans-ui text-stone-600 dark:text-stone-400 max-w-sm mx-auto leading-relaxed">
            {page.paragraphs?.[2]?.text}
          </p>
          <div className="flex items-center justify-center gap-3 text-xs">
            <button
              type="button"
              onClick={() => onNavigateToPage?.(2)}
              className="px-4 py-2 bg-amber-800 hover:bg-amber-900 text-amber-50 rounded-lg font-sans-ui font-medium transition-colors shadow-sm cursor-pointer"
            >
              Comenzar Lectura
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Handle Table of Contents
  if (page.type === 'table_of_contents') {
    return (
      <div className="h-full flex flex-col justify-between p-6 md:p-8 select-text">
        <div>
          <div className="flex items-center justify-between border-b border-amber-600/20 pb-3 mb-5">
            <div>
              <span className="text-[11px] uppercase tracking-widest font-sans-ui text-amber-700 dark:text-amber-400 font-medium">
                Estructura de la Obra
              </span>
              <h2 className="text-xl md:text-2xl font-display-royal font-semibold text-stone-900 dark:text-stone-100">
                {page.chapterTitle}
              </h2>
            </div>
            <BookOpen className="w-5 h-5 text-amber-600/70 dark:text-amber-400/70" />
          </div>

          <div className="space-y-2 text-stone-800 dark:text-stone-200">
            {page.paragraphs?.map((p, idx) => {
              // Target page calculation: TOC starts at page 4 for chapter 1, etc.
              const targetPage = idx === 0 ? 4 : idx === 9 ? 22 : 4 + idx * 2;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => onNavigateToPage?.(targetPage)}
                  className="w-full text-left py-1.5 px-2.5 rounded-lg hover:bg-amber-600/10 transition-colors flex items-center justify-between group cursor-pointer text-xs md:text-sm"
                >
                  <span className="font-serif-book group-hover:text-amber-900 dark:group-hover:text-amber-300 font-medium truncate">
                    {p.text}
                  </span>
                  <span className="font-mono text-stone-400 dark:text-stone-500 text-xs shrink-0 ml-2">
                    pág. {targetPage}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {page.didYouKnow && (
          <div className="mt-4 p-3 bg-amber-600/10 border border-amber-600/20 rounded-lg text-xs text-stone-700 dark:text-stone-300 font-sans-ui flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">{page.didYouKnow}</p>
          </div>
        )}

        <div className="text-center pt-3 border-t border-amber-600/20 text-xs text-stone-400 font-mono">
          III
        </div>
      </div>
    );
  }

  // Handle Activities / Quiz view inside page
  if (page.type === 'activities') {
    return (
      <div className="h-full flex flex-col justify-between p-6 md:p-8 select-text">
        <div>
          <div className="flex items-center justify-between border-b border-amber-600/20 pb-3 mb-4">
            <div>
              <span className="text-[11px] uppercase tracking-widest font-sans-ui text-amber-700 dark:text-amber-400 font-medium">
                Evaluación DELE B2
              </span>
              <h2 className="text-xl md:text-2xl font-display-royal font-semibold text-stone-900 dark:text-stone-100">
                {page.chapterTitle}
              </h2>
            </div>
            <GraduationCap className="w-5 h-5 text-amber-600/80 dark:text-amber-400/80" />
          </div>

          <div className="space-y-4 text-sm text-stone-800 dark:text-stone-200">
            {page.paragraphs?.map((p) => (
              <p key={p.id} className="font-sans-ui leading-relaxed">
                {renderInteractiveText(p.text, p.glossaryIds)}
              </p>
            ))}

            <div className="p-4 bg-amber-500/10 border border-amber-600/30 rounded-xl space-y-3 mt-4">
              <h4 className="font-display-royal font-semibold text-amber-900 dark:text-amber-200 text-base">
                Cuestionario de Comprensión Lectora B2
              </h4>
              <p className="text-xs text-stone-600 dark:text-stone-300">
                Ponga a prueba su comprensión de los hechos históricos, vocabulario formal y expresiones idiomáticas de la crónica.
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={onOpenQuiz}
                  className="px-4 py-2 bg-amber-800 hover:bg-amber-900 text-amber-100 rounded-lg text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                >
                  Comenzar Evaluación Interactiva
                </button>
                <button
                  type="button"
                  onClick={onOpenGlossary}
                  className="px-3 py-2 border border-amber-700/40 text-amber-900 dark:text-amber-300 hover:bg-amber-500/10 rounded-lg text-xs font-medium transition-colors cursor-pointer"
                >
                  Repasar Glosario Completo
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center pt-3 border-t border-amber-600/20 text-xs text-stone-400 font-mono">
          Página {page.pageNumber}
        </div>
      </div>
    );
  }

  // Handle Glossary Page view
  if (page.type === 'glossary_view') {
    return (
      <div className="h-full flex flex-col justify-between p-6 md:p-8 select-text">
        <div>
          <div className="flex items-center justify-between border-b border-amber-600/20 pb-3 mb-4">
            <div>
              <span className="text-[11px] uppercase tracking-widest font-sans-ui text-amber-700 dark:text-amber-400 font-medium">
                Apéndice Filológico
              </span>
              <h2 className="text-xl md:text-2xl font-display-royal font-semibold text-stone-900 dark:text-stone-100">
                {page.chapterTitle}
              </h2>
            </div>
            <BookOpen className="w-5 h-5 text-amber-600/80 dark:text-amber-400/80" />
          </div>

          <p className="text-xs text-stone-600 dark:text-stone-400 font-sans-ui mb-3 leading-relaxed">
            {page.paragraphs?.[0]?.text}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs overflow-y-auto max-h-[380px] pr-1">
            {Object.values(GLOSSARY).slice(0, 10).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onTermClick(item)}
                className="text-left p-2 rounded-lg bg-stone-500/5 hover:bg-amber-500/10 border border-stone-300/40 dark:border-stone-800 transition-colors cursor-pointer"
              >
                <div className="flex items-baseline justify-between">
                  <span className="font-display-royal font-bold text-amber-900 dark:text-amber-300">
                    {item.word}
                  </span>
                  <span className="text-[10px] text-stone-400 italic">{item.category}</span>
                </div>
                <p className="text-[11px] text-stone-600 dark:text-stone-400 line-clamp-1 mt-0.5">
                  {item.definition}
                </p>
              </button>
            ))}
          </div>

          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={onOpenGlossary}
              className="px-4 py-1.5 bg-amber-800/80 hover:bg-amber-800 text-amber-100 rounded-lg text-xs font-medium cursor-pointer shadow-sm transition-colors"
            >
              Abrir Glosario Completo con Audio
            </button>
          </div>
        </div>

        <div className="text-center pt-3 border-t border-amber-600/20 text-xs text-stone-400 font-mono">
          Página {page.pageNumber}
        </div>
      </div>
    );
  }

  // Standard Story & Illustration Pages
  return (
    <div className="h-full flex flex-col justify-between p-6 md:p-8 select-text">
      {/* Header */}
      <div>
        <div className="flex items-start justify-between border-b border-amber-600/20 pb-2 mb-4">
          <div className="space-y-0.5">
            <span className="text-[11px] uppercase tracking-widest font-sans-ui text-amber-700 dark:text-amber-400 font-medium">
              {page.chapterTitle}
            </span>
            {page.subtitle && (
              <h3 className="text-sm md:text-base font-display-royal font-semibold text-stone-800 dark:text-stone-200">
                {page.subtitle}
              </h3>
            )}
          </div>
          {onToggleBookmark && (
            <button
              type="button"
              onClick={onToggleBookmark}
              className={`p-1.5 rounded-md transition-colors cursor-pointer ${
                isBookmarked
                  ? 'text-amber-600 bg-amber-600/20'
                  : 'text-stone-400 hover:text-stone-600 dark:hover:text-stone-300'
              }`}
              title={isBookmarked ? 'Página marcada' : 'Marcar página'}
              aria-label={isBookmarked ? 'Quitar marcador' : 'Marcar página'}
            >
              <Bookmark className="w-4 h-4 fill-current" />
            </button>
          )}
        </div>

        {/* Embedded Illustration if present */}
        {page.image && (
          <div className="mb-4">
            <div className="relative rounded-lg overflow-hidden border border-amber-600/30 shadow-md">
              <img
                src={page.image.src}
                alt={page.image.alt}
                className="w-full h-auto max-h-[220px] md:max-h-[260px] object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <p className="text-[11px] text-stone-500 dark:text-stone-400 font-serif-book italic mt-1 text-center">
              {page.image.caption}
            </p>
          </div>
        )}

        {/* Paragraphs */}
        <div className={`space-y-3 font-serif-book text-stone-900 dark:text-stone-100 ${getFontSizeClass(fontSize)}`}>
          {page.paragraphs?.map((p, idx) => {
            const isFirst = idx === 0 && !page.image;
            const isCurrentlyReading = activeReadingId === p.id;

            return (
              <div
                key={p.id}
                className={`relative group transition-colors rounded-lg p-1.5 -mx-1.5 ${
                  isCurrentlyReading
                    ? 'bg-amber-400/20 dark:bg-amber-500/20 ring-1 ring-amber-500/50'
                    : 'hover:bg-amber-500/5'
                }`}
              >
                <div className="flex items-start gap-1.5">
                  <p
                    className={`flex-1 text-justify ${
                      isFirst
                        ? 'first-letter:text-4xl md:first-letter:text-5xl first-letter:font-display-royal first-letter:font-bold first-letter:float-left first-letter:mr-2.5 first-letter:mt-0.5 first-letter:text-amber-900 dark:first-letter:text-amber-300'
                        : ''
                    }`}
                  >
                    {renderInteractiveText(p.text, p.glossaryIds)}
                  </p>
                  {onReadParagraph && (
                    <button
                      type="button"
                      onClick={() => onReadParagraph(p.text, p.id)}
                      className="opacity-0 group-hover:opacity-100 text-stone-400 hover:text-amber-700 dark:hover:text-amber-300 p-1 rounded transition-opacity shrink-0 cursor-pointer"
                      title="Escuchar este párrafo"
                      aria-label="Escuchar párrafo"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Quote if present */}
        {page.quote && (
          <div className="my-4 py-3 px-4 border-y border-amber-600/30 text-center font-serif-book">
            <p className="italic text-base md:text-lg text-amber-950 dark:text-amber-200">
              «{page.quote.text}»
            </p>
            <p className="text-[11px] uppercase tracking-wider text-stone-500 dark:text-stone-400 font-sans-ui mt-1">
              — {page.quote.author}
            </p>
          </div>
        )}

        {/* Grammar Focus B2 Box */}
        {page.grammarFocus && (
          <div className="mt-4 p-3 bg-stone-500/5 dark:bg-stone-800/40 border border-stone-300 dark:border-stone-800 rounded-lg text-xs space-y-1.5 font-sans-ui">
            <div className="flex items-center gap-1.5 text-amber-800 dark:text-amber-400 font-semibold">
              <GraduationCap className="w-4 h-4" />
              <span>{page.grammarFocus.title}</span>
            </div>
            <p className="text-stone-700 dark:text-stone-300 leading-relaxed">
              {page.grammarFocus.explanation}
            </p>
            <ul className="list-disc list-inside space-y-0.5 text-stone-600 dark:text-stone-400 font-serif-book italic pl-1">
              {page.grammarFocus.examples.map((ex, i) => (
                <li key={i}>{ex}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Did You Know box */}
        {page.didYouKnow && !page.grammarFocus && (
          <div className="mt-4 p-2.5 bg-amber-600/10 border border-amber-600/20 rounded-lg text-xs font-sans-ui text-stone-700 dark:text-stone-300 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-amber-800 dark:text-amber-300 block mb-0.5">
                Curiosidad Histórica:
              </span>
              <p className="leading-relaxed">{page.didYouKnow}</p>
            </div>
          </div>
        )}
      </div>

      {/* Footer Page Number */}
      <div className="text-center pt-3 border-t border-amber-600/20 text-xs text-stone-500 dark:text-stone-400 font-mono">
        {page.pageNumber}
      </div>
    </div>
  );
};

function escapeRegExp(string: string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
