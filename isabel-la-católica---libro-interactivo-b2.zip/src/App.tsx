/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { BOOK_PAGES } from './data/bookContent';
import { FontSize, GlossaryItem, PaperTheme } from './types/book';
import { TopNav } from './components/TopNav';
import { BookViewer } from './components/BookViewer';
import { AudioBar } from './components/AudioBar';
import { GlossaryPopover } from './components/GlossaryPopover';
import { FullGlossaryModal } from './components/FullGlossaryModal';
import { ChaptersDrawer } from './components/ChaptersDrawer';
import { QuizModal } from './components/QuizModal';
import { SettingsModal } from './components/SettingsModal';
import { speechReader } from './utils/audio';

export default function App() {
  // Page index state (persisted)
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('isabel_b2_current_page');
      return saved ? Math.min(Math.max(0, parseInt(saved, 10)), BOOK_PAGES.length - 1) : 0;
    } catch {
      return 0;
    }
  });

  // Reading preferences
  const [fontSize, setFontSize] = useState<FontSize>(() => {
    try {
      const saved = localStorage.getItem('isabel_b2_fontsize');
      return (saved as FontSize) || 'md';
    } catch {
      return 'md';
    }
  });

  const [paperTheme, setPaperTheme] = useState<PaperTheme>(() => {
    try {
      const saved = localStorage.getItem('isabel_b2_theme');
      return (saved as PaperTheme) || 'parchment';
    } catch {
      return 'parchment';
    }
  });

  const [pageSoundEnabled, setPageSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('isabel_b2_sound');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [activeReadingId, setActiveReadingId] = useState<string | null>(null);

  // Modals state
  const [selectedGlossaryTerm, setSelectedGlossaryTerm] = useState<GlossaryItem | null>(null);
  const [isFullGlossaryOpen, setIsFullGlossaryOpen] = useState(false);
  const [isChaptersDrawerOpen, setIsChaptersDrawerOpen] = useState(false);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Audio queue tracking
  const paragraphQueueRef = useRef<{ id: string; text: string }[]>([]);
  const currentQueueIndexRef = useRef<number>(0);

  // Persist settings
  useEffect(() => {
    try {
      localStorage.setItem('isabel_b2_current_page', currentPageIndex.toString());
    } catch {
      // ignore
    }
  }, [currentPageIndex]);

  useEffect(() => {
    try {
      localStorage.setItem('isabel_b2_fontsize', fontSize);
    } catch {
      // ignore
    }
  }, [fontSize]);

  useEffect(() => {
    try {
      localStorage.setItem('isabel_b2_theme', paperTheme);
    } catch {
      // ignore
    }
  }, [paperTheme]);

  useEffect(() => {
    try {
      localStorage.setItem('isabel_b2_sound', pageSoundEnabled.toString());
    } catch {
      // ignore
    }
  }, [pageSoundEnabled]);

  // Handle page turn stop/reset speech
  const handlePageChange = useCallback((newIndex: number) => {
    speechReader.stop();
    setIsPlaying(false);
    setIsPaused(false);
    setActiveReadingId(null);
    setCurrentPageIndex(newIndex);
  }, []);

  // Sequential text reader for active open spread
  const readQueueSequentially = useCallback(() => {
    const queue = paragraphQueueRef.current;
    const idx = currentQueueIndexRef.current;

    if (idx >= queue.length) {
      setIsPlaying(false);
      setIsPaused(false);
      setActiveReadingId(null);
      return;
    }

    const item = queue[idx];
    setActiveReadingId(item.id);
    setIsPlaying(true);
    setIsPaused(false);

    speechReader.speakText({
      text: item.text,
      rate: speechRate,
      onStart: () => {
        setIsPlaying(true);
        setIsPaused(false);
      },
      onEnd: () => {
        currentQueueIndexRef.current += 1;
        readQueueSequentially();
      },
      onError: () => {
        setIsPlaying(false);
        setIsPaused(false);
        setActiveReadingId(null);
      },
    });
  }, [speechRate]);

  // Start reading current visible pages
  const handlePlayCurrentPage = useCallback(() => {
    speechReader.stop();

    // Determine visible pages
    const isCover = currentPageIndex === 0;
    const pagesToRead: typeof BOOK_PAGES = [];

    if (isCover) {
      pagesToRead.push(BOOK_PAGES[0]);
    } else {
      const leftIdx = currentPageIndex % 2 === 1 ? currentPageIndex : currentPageIndex - 1;
      const rightIdx = leftIdx + 1;
      if (leftIdx >= 0 && leftIdx < BOOK_PAGES.length) pagesToRead.push(BOOK_PAGES[leftIdx]);
      if (rightIdx >= 0 && rightIdx < BOOK_PAGES.length) pagesToRead.push(BOOK_PAGES[rightIdx]);
    }

    const queue: { id: string; text: string }[] = [];
    pagesToRead.forEach(p => {
      if (p.subtitle) {
        queue.push({ id: `${p.id}-subtitle`, text: p.subtitle });
      }
      p.paragraphs?.forEach(para => {
        queue.push({ id: para.id, text: para.text });
      });
      if (p.quote) {
        queue.push({ id: `${p.id}-quote`, text: `${p.quote.text}. ${p.quote.author}` });
      }
      if (p.grammarFocus) {
        queue.push({ id: `${p.id}-grammar`, text: `${p.grammarFocus.title}. ${p.grammarFocus.explanation}` });
      }
    });

    if (queue.length === 0) return;

    paragraphQueueRef.current = queue;
    currentQueueIndexRef.current = 0;
    readQueueSequentially();
  }, [currentPageIndex, readQueueSequentially]);

  // Read single paragraph
  const handleReadParagraph = useCallback((text: string, id: string) => {
    speechReader.stop();
    setActiveReadingId(id);
    setIsPlaying(true);
    setIsPaused(false);

    speechReader.speakText({
      text,
      rate: speechRate,
      onEnd: () => {
        setIsPlaying(false);
        setIsPaused(false);
        setActiveReadingId(null);
      },
      onError: () => {
        setIsPlaying(false);
        setIsPaused(false);
        setActiveReadingId(null);
      },
    });
  }, [speechRate]);

  const handlePause = () => {
    speechReader.pause();
    setIsPaused(true);
  };

  const handleResume = () => {
    speechReader.resume();
    setIsPaused(false);
  };

  const handleStop = () => {
    speechReader.stop();
    setIsPlaying(false);
    setIsPaused(false);
    setActiveReadingId(null);
  };

  const handleSpeedChange = (rate: number) => {
    setSpeechRate(rate);
    if (isPlaying) {
      handlePlayCurrentPage();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-900 text-stone-100 font-sans-ui selection:bg-amber-400 selection:text-amber-950">
      {/* Top Bar compliant with 3-Zone contract */}
      <TopNav
        onGoToCover={() => handlePageChange(0)}
        onOpenChapters={() => setIsChaptersDrawerOpen(true)}
        onOpenGlossary={() => setIsFullGlossaryOpen(true)}
        onOpenQuiz={() => setIsQuizOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onStartReading={handlePlayCurrentPage}
      />

      {/* Main Reading Stage */}
      <main className="flex-1 flex flex-col justify-center items-center px-3 sm:px-6 py-4 md:py-8">
        <BookViewer
          currentPageIndex={currentPageIndex}
          onPageChange={handlePageChange}
          fontSize={fontSize}
          paperTheme={paperTheme}
          pageSoundEnabled={pageSoundEnabled}
          activeReadingId={activeReadingId}
          onTermClick={(term) => setSelectedGlossaryTerm(term)}
          onReadParagraph={handleReadParagraph}
          onOpenQuiz={() => setIsQuizOpen(true)}
          onOpenGlossary={() => setIsFullGlossaryOpen(true)}
        />
      </main>

      {/* Floating Audio Controller Strip */}
      <div className="sticky bottom-4 z-30 max-w-2xl w-full mx-auto px-4">
        <AudioBar
          onPlayCurrentPage={handlePlayCurrentPage}
          onPause={handlePause}
          onResume={handleResume}
          onStop={handleStop}
          isPlaying={isPlaying}
          isPaused={isPaused}
          activeReadingId={activeReadingId}
          speechRate={speechRate}
          onSpeedChange={handleSpeedChange}
          pageSoundEnabled={pageSoundEnabled}
          onTogglePageSound={() => setPageSoundEnabled(prev => !prev)}
        />
      </div>

      {/* Modals & Drawers */}
      {selectedGlossaryTerm && (
        <GlossaryPopover
          item={selectedGlossaryTerm}
          onClose={() => setSelectedGlossaryTerm(null)}
          onOpenFullGlossary={() => setIsFullGlossaryOpen(true)}
        />
      )}

      <FullGlossaryModal
        isOpen={isFullGlossaryOpen}
        onClose={() => setIsFullGlossaryOpen(false)}
      />

      <ChaptersDrawer
        isOpen={isChaptersDrawerOpen}
        onClose={() => setIsChaptersDrawerOpen(false)}
        currentPageIndex={currentPageIndex}
        onSelectPage={handlePageChange}
      />

      <QuizModal
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        fontSize={fontSize}
        onFontSizeChange={setFontSize}
        paperTheme={paperTheme}
        onPaperThemeChange={setPaperTheme}
        pageSoundEnabled={pageSoundEnabled}
        onTogglePageSound={() => setPageSoundEnabled(prev => !prev)}
      />
    </div>
  );
}
