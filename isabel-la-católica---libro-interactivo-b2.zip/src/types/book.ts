/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type WordCategory = 
  | 'sustantivo' 
  | 'verbo' 
  | 'adjetivo' 
  | 'locución adverbial' 
  | 'locución conjuntiva' 
  | 'expresión idiomática';

export interface GlossaryItem {
  id: string;
  word: string;
  category: WordCategory;
  definition: string;
  example: string;
  translationEn: string;
  pronunciationTip?: string;
  chapterNumber?: number;
}

export interface GrammarFocus {
  title: string;
  explanation: string;
  examples: string[];
}

export interface PageParagraph {
  id: string;
  text: string;
  glossaryIds?: string[];
}

export type PageType = 
  | 'cover' 
  | 'table_of_contents' 
  | 'story' 
  | 'illustration' 
  | 'activities' 
  | 'glossary_view';

export interface BookPage {
  id: string;
  pageNumber: number; // 1-based physical page number
  chapterIndex?: number; // 0 for intro, 1..N
  chapterTitle?: string;
  subtitle?: string;
  type: PageType;
  paragraphs?: PageParagraph[];
  quote?: {
    text: string;
    author: string;
  };
  image?: {
    src: string;
    caption: string;
    alt: string;
  };
  didYouKnow?: string;
  grammarFocus?: GrammarFocus;
}

export interface QuizQuestion {
  id: string;
  chapterNumber: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export type PaperTheme = 'parchment' | 'sepia' | 'white' | 'night';
export type FontSize = 'sm' | 'md' | 'lg' | 'xl';
